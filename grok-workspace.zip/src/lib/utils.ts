import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function arabicPercent(n: number) {
  return `${Math.round(n)}٪`;
}

export function formatHours(hours: number) {
  if (hours === 1) return "ساعة واحدة";
  if (hours === 2) return "ساعتان";
  if (hours < 11) return `${hours} ساعات`;
  return `${hours} ساعة`;
}

export function formatMinutes(min: number) {
  if (min < 60) return `${min} دقيقة`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  return m ? `${formatHours(h)} و${m} دقيقة` : formatHours(h);
}

export function initials(name: string | null | undefined) {
  const t = (name ?? "").trim();
  if (!t) return "ط";
  return t.slice(0, 1);
}
