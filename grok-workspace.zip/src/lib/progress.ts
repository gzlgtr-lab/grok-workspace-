import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import {
  COURSES,
  DOMAIN_LABEL,
  LESSONS,
  courseProgress,
  getCourse,
  getLesson,
  getQuiz,
  gradeQuiz,
  lessonsOfCourse,
  suggestedPlan,
  type Domain,
} from "@/lib/curriculum";

function code() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "ILM-";
  for (let i = 0; i < 8; i++) s += alphabet[Math.floor(Math.random() * alphabet.length)];
  return s;
}

type SqlClient = Awaited<ReturnType<typeof getSql>>;

async function ensureProfile(sql: SqlClient, userId: string) {
  const existing = await sql<{
    user_id: string;
    display_name: string | null;
    goal: string | null;
    weekly_minutes: number;
    current_track: string | null;
    current_stage: string | null;
    placement_completed: boolean;
    placement_scores: unknown;
    font_size: string;
    theme: string;
  }>`select user_id, display_name, goal, weekly_minutes, current_track, current_stage, placement_completed, placement_scores, font_size, theme from student_profiles where user_id = ${userId}`;
  if (existing[0]) return existing[0];
  await sql`insert into student_profiles (user_id, display_name) values (${userId}, ${"طالب"}) on conflict (user_id) do nothing`;
  await sql`insert into user_roles (user_id, role) values (${userId}, ${"student"}) on conflict (user_id) do nothing`;
  await sql`insert into notifications (user_id, title, body, href) values (${userId}, ${"مرحبًا بك في أكاديمية العلم"}, ${"ابدأ باختبار تحديد المستوى أو بأول درس في التهيئة."}, ${"/placement"})`;
  const created = await sql<{
    user_id: string;
    display_name: string | null;
    goal: string | null;
    weekly_minutes: number;
    current_track: string | null;
    current_stage: string | null;
    placement_completed: boolean;
    placement_scores: unknown;
    font_size: string;
    theme: string;
  }>`select user_id, display_name, goal, weekly_minutes, current_track, current_stage, placement_completed, placement_scores, font_size, theme from student_profiles where user_id = ${userId}`;
  return created[0];
}

async function completeLessonRow(sql: SqlClient, userId: string, lessonId: string, score?: number) {
  const lesson = getLesson(lessonId);
  if (!lesson) throw new Error("الدرس غير موجود");
  await sql`insert into lesson_progress (user_id, lesson_id, status, mastery_score, completed_at, updated_at)
    values (${userId}, ${lessonId}, ${"completed"}, ${score ?? null}, now(), now())
    on conflict (user_id, lesson_id) do update set status = ${"completed"}, mastery_score = excluded.mastery_score, completed_at = now(), updated_at = now()`;
  const courseLessons = lessonsOfCourse(lesson.courseId).filter((l) => l.available);
  const done = await sql<{ lesson_id: string }>`select lesson_id from lesson_progress where user_id = ${userId} and status = ${"completed"}`;
  const completed = new Set(done.map((d) => d.lesson_id));
  if (courseLessons.length && courseLessons.every((l) => completed.has(l.id))) {
    const course = getCourse(lesson.courseId);
    const existing = await sql<{ id: number }>`select id from certificates where user_id = ${userId} and kind = ${"course"} and target_id = ${lesson.courseId}`;
    if (course && !existing[0]) {
      const verify = code();
      await sql`insert into certificates (user_id, kind, target_id, title, hours, score, verify_code)
        values (${userId}, ${"course"}, ${course.id}, ${course.title}, ${course.hours}, ${score ?? null}, ${verify})`;
      await sql`insert into notifications (user_id, title, body, href) values (${userId}, ${"شهادة مقرر"}, ${"أتممت مقرر: " + course.title}, ${"/dashboard/certificates"})`;
    }
  }
}

export const getOrCreateProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    return ensureProfile(sql, context.userId);
  });

export const updateProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      display_name: z.string().max(80).optional(),
      goal: z.string().max(40).optional(),
      weekly_minutes: z.number().min(10).max(180).optional(),
      font_size: z.string().optional(),
      theme: z.string().optional(),
    }),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    await sql`update student_profiles set
      display_name = coalesce(${data.display_name ?? null}, display_name),
      goal = coalesce(${data.goal ?? null}, goal),
      weekly_minutes = coalesce(${data.weekly_minutes ?? null}, weekly_minutes),
      font_size = coalesce(${data.font_size ?? null}, font_size),
      theme = coalesce(${data.theme ?? null}, theme),
      updated_at = now()
      where user_id = ${context.userId}`;
    return { ok: true };
  });

export type ProgressRow = {
  lesson_id: string;
  status: string;
  mastery_score: number | null;
  completed_at: string | null;
};

export const getDashboard = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const profile = await ensureProfile(sql, context.userId);

    const progress = await sql<ProgressRow>`select lesson_id, status, mastery_score, completed_at from lesson_progress where user_id = ${context.userId}`;
    const attempts = await sql<{
      id: number;
      quiz_id: string;
      score: number;
      total: number;
      percent: number;
      passed: boolean;
      created_at: string;
    }>`select id, quiz_id, score, total, percent, passed, created_at from quiz_attempts where user_id = ${context.userId} order by id desc limit 40`;
    const notes = await sql<{ id: number; lesson_id: string; body: string; created_at: string }>`select id, lesson_id, body, created_at from student_notes where user_id = ${context.userId} order by id desc limit 50`;
    const bookmarks = await sql<{ lesson_id: string }>`select lesson_id from bookmarks where user_id = ${context.userId}`;
    const certificates = await sql<{
      id: number;
      kind: string;
      target_id: string;
      title: string;
      hours: number | null;
      score: number | null;
      verify_code: string;
      issued_at: string;
    }>`select id, kind, target_id, title, hours, score, verify_code, issued_at from certificates where user_id = ${context.userId} order by id desc`;
    const projects = await sql<{
      id: number;
      title: string;
      description: string | null;
      status: string;
      course_id: string | null;
      created_at: string;
    }>`select id, title, description, status, course_id, created_at from projects where user_id = ${context.userId} order by id desc`;
    const notifications = await sql<{
      id: number;
      title: string;
      body: string | null;
      href: string | null;
      read: boolean;
      created_at: string;
    }>`select id, title, body, href, read, created_at from notifications where user_id = ${context.userId} order by id desc limit 20`;
    const [roleRow] = await sql<{ role: string }>`select role from user_roles where user_id = ${context.userId}`;
    const [plan] = await sql<{
      kind: string;
      minutes_per_day: number;
      lesson_ids: unknown;
    }>`select kind, minutes_per_day, lesson_ids from study_plans where user_id = ${context.userId}`;

    const completed = new Set(progress.filter((p) => p.status === "completed").map((p) => p.lesson_id));
    const completedCourses = new Set(
      COURSES.filter((c) => {
        const lessons = lessonsOfCourse(c.id).filter((l) => l.available);
        return lessons.length > 0 && lessons.every((l) => completed.has(l.id));
      }).map((c) => c.id),
    );

    const skills: Record<string, { score: number; total: number; label: string }> = {};
    for (const a of attempts) {
      const quiz = getQuiz(a.quiz_id);
      if (!quiz) continue;
      // approximate domain from first question skill via grade stored percent
    }
    for (const p of progress) {
      const lesson = getLesson(p.lesson_id);
      if (!lesson) continue;
      const course = getCourse(lesson.courseId);
      if (!course) continue;
      const slot = skills[course.domain] ?? { score: 0, total: 0, label: DOMAIN_LABEL[course.domain] };
      slot.total += 1;
      if (p.status === "completed") slot.score += 1;
      skills[course.domain] = slot;
    }

    const overallLessons = LESSONS.filter((l) => l.available);
    const overallDone = overallLessons.filter((l) => completed.has(l.id)).length;

    return {
      profile,
      role: roleRow?.role ?? "student",
      progress,
      attempts,
      notes,
      bookmarks: bookmarks.map((b) => b.lesson_id),
      certificates,
      projects,
      notifications,
      plan,
      completedLessonIds: [...completed],
      completedCourseIds: [...completedCourses],
      skills,
      overall: {
        done: overallDone,
        total: overallLessons.length,
        percent: overallLessons.length ? Math.round((overallDone / overallLessons.length) * 100) : 0,
      },
      courseStats: COURSES.map((c) => ({ id: c.id, ...courseProgress(c.id, completed) })),
    };
  });

export const markLessonComplete = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ lessonId: z.string(), score: z.number().optional() }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await completeLessonRow(sql, context.userId, data.lessonId, data.score);
    return { ok: true };
  });

export const toggleBookmark = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ lessonId: z.string() }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{ lesson_id: string }>`select lesson_id from bookmarks where user_id = ${context.userId} and lesson_id = ${data.lessonId}`;
    if (rows[0]) {
      await sql`delete from bookmarks where user_id = ${context.userId} and lesson_id = ${data.lessonId}`;
      return { bookmarked: false };
    }
    await sql`insert into bookmarks (user_id, lesson_id) values (${context.userId}, ${data.lessonId})`;
    return { bookmarked: true };
  });

export const saveNote = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ lessonId: z.string(), body: z.string().min(1).max(4000) }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`insert into student_notes (user_id, lesson_id, body) values (${context.userId}, ${data.lessonId}, ${data.body})`;
    return { ok: true };
  });

export const submitQuiz = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ quizId: z.string(), answers: z.record(z.number()) }))
  .handler(async ({ context, data }) => {
    const quiz = getQuiz(data.quizId);
    if (!quiz) throw new Error("الاختبار غير موجود");
    const result = gradeQuiz(data.quizId, data.answers);
    const passed = quiz.kind === "placement" ? true : result.percent >= quiz.passPercent;
    const sql = await getSql();
    const inserted = await sql<{ id: number }>`insert into quiz_attempts (user_id, quiz_id, answers, score, total, percent, passed)
      values (${context.userId}, ${data.quizId}, ${JSON.stringify(data.answers)}::jsonb, ${result.score}, ${result.total}, ${result.percent}, ${passed})
      returning id`;

    if (quiz.kind === "placement") {
      await sql`update student_profiles set placement_completed = true, placement_scores = ${JSON.stringify(result.skills)}::jsonb, updated_at = now() where user_id = ${context.userId}`;
    }

    if (quiz.kind === "lesson" && passed) {
      const lessonId = quiz.id.replace(/-q$/, "");
      if (getLesson(lessonId)) {
        await completeLessonRow(sql, context.userId, lessonId, result.percent);
      }
    }

    return { attemptId: inserted[0]?.id, ...result, passed, passPercent: quiz.passPercent };
  });

export const saveStudyPlan = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ kind: z.string(), minutes: z.number().min(10).max(180) }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const dashCompleted = await sql<{ lesson_id: string }>`select lesson_id from lesson_progress where user_id = ${context.userId} and status = ${"completed"}`;
    const completed = new Set(dashCompleted.map((d) => d.lesson_id));
    const [profile] = await sql<{ goal: string | null }>`select goal from student_profiles where user_id = ${context.userId}`;
    const plan = suggestedPlan({
      goal: profile?.goal ?? data.kind,
      minutes: data.minutes,
      completed,
    });
    const sql = await getSql();
    await sql`insert into study_plans (user_id, kind, minutes_per_day, lesson_ids, generated_at)
      values (${context.userId}, ${data.kind}, ${data.minutes}, ${JSON.stringify(plan.lessonIds)}::jsonb, now())
      on conflict (user_id) do update set kind = excluded.kind, minutes_per_day = excluded.minutes_per_day, lesson_ids = excluded.lesson_ids, generated_at = now()`;
    await sql`update student_profiles set goal = ${data.kind}, weekly_minutes = ${data.minutes}, updated_at = now() where user_id = ${context.userId}`;
    return plan;
  });

export const saveProject = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    z.object({
      title: z.string().min(3).max(120),
      description: z.string().max(4000).optional(),
      courseId: z.string().optional(),
    }),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`insert into projects (user_id, title, description, course_id, status)
      values (${context.userId}, ${data.title}, ${data.description ?? ""}, ${data.courseId ?? null}, ${"submitted"})`;
    return { ok: true };
  });

export const markNotificationRead = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(z.object({ id: z.number() }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`update notifications set read = true where id = ${data.id} and user_id = ${context.userId}`;
    return { ok: true };
  });

export const verifyCertificate = createServerFn({ method: "GET" })
  .validator(z.object({ code: z.string() }))
  .handler(async ({ data }) => {
    const sql = await getSql();
    const rows = await sql<{
      title: string;
      kind: string;
      hours: number | null;
      score: number | null;
      issued_at: string;
      verify_code: string;
    }>`select title, kind, hours, score, issued_at, verify_code from certificates where verify_code = ${data.code}`;
    return rows[0] ?? null;
  });

export const getMyCertificate = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator(z.object({ id: z.number() }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{
      id: number;
      title: string;
      kind: string;
      hours: number | null;
      score: number | null;
      issued_at: string;
      verify_code: string;
    }>`select id, title, kind, hours, score, issued_at, verify_code from certificates where id = ${data.id} and user_id = ${context.userId}`;
    return rows[0] ?? null;
  });

export const claimAdmin = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const admins = await sql<{ user_id: string }>`select user_id from user_roles where role = ${"admin"}`;
    if (admins.length === 0) {
      await sql`insert into user_roles (user_id, role) values (${context.userId}, ${"admin"}) on conflict (user_id) do update set role = ${"admin"}`;
      return { role: "admin", claimed: true };
    }
    const [mine] = await sql<{ role: string }>`select role from user_roles where user_id = ${context.userId}`;
    return { role: mine?.role ?? "student", claimed: false };
  });

export const getAdminStats = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const [role] = await sql<{ role: string }>`select role from user_roles where user_id = ${context.userId}`;
    if (role?.role !== "admin") {
      return { forbidden: true as const, role: role?.role ?? "student" };
    }
    const [users] = await sql<{ n: number }>`select count(*)::int as n from student_profiles`;
    const [attempts] = await sql<{ n: number }>`select count(*)::int as n from quiz_attempts`;
    const [certs] = await sql<{ n: number }>`select count(*)::int as n from certificates`;
    const [reviews] = await sql<{ n: number }>`select count(*)::int as n from content_reviews`;
    const recent = await sql<{ user_id: string; display_name: string | null; created_at: string }>`select user_id, display_name, created_at from student_profiles order by created_at desc limit 12`;
    return {
      forbidden: false as const,
      role: "admin",
      users: users?.n ?? 0,
      attempts: attempts?.n ?? 0,
      certs: certs?.n ?? 0,
      reviews: reviews?.n ?? 0,
      recent,
      catalog: {
        courses: COURSES.length,
        lessons: LESSONS.length,
        available: LESSONS.filter((l) => l.available).length,
      },
    };
  });

export type SkillMap = Partial<Record<Domain, { score: number; total: number }>>;
