export type StageId = "0" | "1" | "2" | "3" | "4" | "5" | "researcher";
export type Level = "intro" | "foundation" | "intermediate" | "advanced" | "research";
export type Domain =
  | "orientation"
  | "aqidah"
  | "quran"
  | "hadith"
  | "fiqh"
  | "usul"
  | "arabic"
  | "seerah"
  | "history"
  | "akhlaq"
  | "research"
  | "contemporary";
export type QuestionType = "mcq" | "tf" | "order";
export type SourceKind =
  | "original"
  | "commentary"
  | "textbook"
  | "paper"
  | "lexicon"
  | "audio"
  | "video";

export type TrackId =
  | "general"
  | "talib"
  | "teacher"
  | "researcher"
  | "aqidah"
  | "fiqh"
  | "hadith"
  | "tafsir"
  | "usul"
  | "arabic"
  | "history";

export interface Stage {
  id: StageId;
  order: number;
  title: string;
  subtitle: string;
  goal: string;
  duration: string;
  color: "forest" | "gold";
}

export interface Track {
  id: TrackId;
  title: string;
  audience: string;
  description: string;
  courseIds: string[];
}

export interface Course {
  id: string;
  title: string;
  description: string;
  stageId: StageId;
  domain: Domain;
  level: Level;
  hours: number;
  prerequisites: string[];
  objectives: string[];
  sources: string[];
  moduleIds: string[];
}

export interface Module {
  id: string;
  courseId: string;
  order: number;
  title: string;
  summary: string;
  lessonIds: string[];
}

export interface Evidence {
  kind: "quran" | "hadith" | "principle";
  text: string;
  source: string;
}

export interface Term {
  term: string;
  definition: string;
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
}

export interface Lesson {
  id: string;
  moduleId: string;
  courseId: string;
  order: number;
  title: string;
  level: Level;
  durationMin: number;
  available: boolean;
  objectives: string[];
  intro: string;
  simple: string;
  intermediate: string;
  advanced: string;
  terms: Term[];
  evidences: Evidence[];
  examples: string[];
  misconceptions: string[];
  thinking: string[];
  activity: string;
  exercise: string;
  summary: string;
  flashcards: Flashcard[];
  furtherReading: string[];
  quizId: string;
}

export interface Question {
  id: string;
  quizId: string;
  type: QuestionType;
  prompt: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  difficulty: "easy" | "medium" | "hard";
  skill: Domain;
}

export interface Quiz {
  id: string;
  kind: "lesson" | "module" | "course" | "stage" | "placement" | "mastery";
  title: string;
  passPercent: number;
  questionIds: string[];
}

export interface LibrarySource {
  id: string;
  title: string;
  author: string;
  domain: Domain;
  kind: SourceKind;
  level: Level;
  era: string;
  description: string;
  relatedCourseIds: string[];
  importance: "core" | "support" | "advanced";
}

export const DOMAIN_LABEL: Record<Domain, string> = {
  orientation: "التهيئة",
  aqidah: "العقيدة",
  quran: "القرآن وعلومه",
  hadith: "الحديث وعلومه",
  fiqh: "الفقه",
  usul: "أصول الفقه",
  arabic: "اللغة العربية",
  seerah: "السيرة",
  history: "التاريخ والحضارة",
  akhlaq: "الأخلاق والتزكية",
  research: "البحث العلمي",
  contemporary: "القضايا المعاصرة",
};

export const LEVEL_LABEL: Record<Level, string> = {
  intro: "تمهيدي",
  foundation: "تأسيسي",
  intermediate: "متوسط",
  advanced: "متقدم",
  research: "بحثي",
};

export const MASTERY_THRESHOLD: Record<Level, number> = {
  intro: 70,
  foundation: 70,
  intermediate: 75,
  advanced: 80,
  research: 85,
};
