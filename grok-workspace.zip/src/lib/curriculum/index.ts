import { COURSES, MODULES, STAGES, TRACKS } from "./data";
import { LESSONS } from "./lessons";
import { SOURCES } from "./library";
import { QUESTIONS, QUIZZES } from "./quizzes";
import type { Course, Domain, Lesson, LibrarySource, Module, Question, Quiz, Stage, Track } from "./types";
import { DOMAIN_LABEL, LEVEL_LABEL } from "./types";

export * from "./types";
export { COURSES, MODULES, STAGES, TRACKS } from "./data";
export { LESSONS } from "./lessons";
export { SOURCES } from "./library";
export { QUESTIONS, QUIZZES } from "./quizzes";

const courseMap = new Map(COURSES.map((c) => [c.id, c]));
const moduleMap = new Map(MODULES.map((m) => [m.id, m]));
const lessonMap = new Map(LESSONS.map((l) => [l.id, l]));
const quizMap = new Map(QUIZZES.map((q) => [q.id, q]));
const questionMap = new Map(QUESTIONS.map((q) => [q.id, q]));
const sourceMap = new Map(SOURCES.map((s) => [s.id, s]));
const stageMap = new Map(STAGES.map((s) => [s.id, s]));
const trackMap = new Map(TRACKS.map((t) => [t.id, t]));

export function getStage(id: string) {
  return stageMap.get(id as Stage["id"]);
}
export function getTrack(id: string) {
  return trackMap.get(id as Track["id"]);
}
export function getCourse(id: string) {
  return courseMap.get(id);
}
export function getModule(id: string) {
  return moduleMap.get(id);
}
export function getLesson(id: string) {
  return lessonMap.get(id);
}
export function getQuiz(id: string) {
  return quizMap.get(id);
}
export function getSource(id: string) {
  return sourceMap.get(id);
}

export function modulesOf(courseId: string) {
  return MODULES.filter((m) => m.courseId === courseId).sort((a, b) => a.order - b.order);
}

export function lessonsOfModule(moduleId: string) {
  return LESSONS.filter((l) => l.moduleId === moduleId).sort((a, b) => a.order - b.order);
}

export function lessonsOfCourse(courseId: string) {
  return modulesOf(courseId).flatMap((m) => lessonsOfModule(m.id));
}

export function questionsOf(quizId: string): Question[] {
  const quiz = quizMap.get(quizId);
  if (!quiz) return [];
  return quiz.questionIds.map((id) => questionMap.get(id)).filter((x): x is Question => Boolean(x));
}

export function coursesOfStage(stageId: string) {
  return COURSES.filter((c) => c.stageId === stageId);
}

export function nextLesson(lesson: Lesson): Lesson | undefined {
  const list = lessonsOfCourse(lesson.courseId);
  const i = list.findIndex((l) => l.id === lesson.id);
  return list[i + 1];
}

export function prevLesson(lesson: Lesson): Lesson | undefined {
  const list = lessonsOfCourse(lesson.courseId);
  const i = list.findIndex((l) => l.id === lesson.id);
  return list[i - 1];
}

export function firstAvailableLesson() {
  return LESSONS.find((l) => l.available) ?? LESSONS[0];
}

export function courseProgress(courseId: string, completed: Set<string>) {
  const lessons = lessonsOfCourse(courseId);
  const available = lessons.filter((l) => l.available);
  const denom = available.length || lessons.length || 1;
  const done = available.filter((l) => completed.has(l.id)).length;
  return { done, total: denom, percent: Math.round((done / denom) * 100) };
}

export function isCourseUnlocked(course: Course, completedCourses: Set<string>) {
  return course.prerequisites.every((id) => completedCourses.has(id));
}

export function readiness(course: Course, completedCourses: Set<string>) {
  if (course.prerequisites.length === 0) return 100;
  const ok = course.prerequisites.filter((id) => completedCourses.has(id)).length;
  return Math.round((ok / course.prerequisites.length) * 100);
}

export function searchCatalog(query: string) {
  const q = query.trim();
  if (!q) return { courses: [] as Course[], lessons: [] as Lesson[], sources: [] as LibrarySource[], tracks: [] as Track[] };
  const hit = (s: string) => s.includes(q);
  return {
    courses: COURSES.filter((c) => hit(c.title) || hit(c.description) || hit(DOMAIN_LABEL[c.domain])),
    lessons: LESSONS.filter((l) => hit(l.title) || hit(l.summary) || hit(l.intro)),
    sources: SOURCES.filter((s) => hit(s.title) || hit(s.author) || hit(s.description)),
    tracks: TRACKS.filter((t) => hit(t.title) || hit(t.description)),
  };
}

export function academyStats() {
  return {
    stages: STAGES.length,
    tracks: TRACKS.length,
    courses: COURSES.length,
    lessons: LESSONS.length,
    availableLessons: LESSONS.filter((l) => l.available).length,
    sources: SOURCES.length,
    questions: QUESTIONS.length,
  };
}

export function suggestedPlan(opts: {
  goal?: string | null;
  minutes: number;
  weak?: Domain[];
  completed: Set<string>;
}) {
  const track = TRACKS.find((t) => t.id === (opts.goal || "general")) ?? TRACKS[0];
  const ids: string[] = [];
  for (const cid of track.courseIds) {
    for (const l of lessonsOfCourse(cid)) {
      if (l.available && !opts.completed.has(l.id)) ids.push(l.id);
      if (ids.length >= 8) break;
    }
    if (ids.length >= 8) break;
  }
  const perDay = Math.max(1, Math.round(opts.minutes / 20));
  return { track, lessonIds: ids, perDay };
}

export function gradeQuiz(quizId: string, answers: Record<string, number>) {
  const questions = questionsOf(quizId);
  let score = 0;
  const review = questions.map((qn) => {
    const chosen = answers[qn.id];
    const ok = chosen === qn.correctIndex;
    if (ok) score += 1;
    return { id: qn.id, ok, chosen, correctIndex: qn.correctIndex, explanation: qn.explanation, skill: qn.skill };
  });
  const total = questions.length || 1;
  const percent = Math.round((score / total) * 100);
  const skills: Partial<Record<Domain, { score: number; total: number }>> = {};
  for (const r of review) {
    const s = skills[r.skill] ?? { score: 0, total: 0 };
    s.total += 1;
    if (r.ok) s.score += 1;
    skills[r.skill] = s;
  }
  return { score, total, percent, review, skills };
}

export { DOMAIN_LABEL, LEVEL_LABEL };

export function moduleOfLesson(lessonId: string): Module | undefined {
  const l = lessonMap.get(lessonId);
  return l ? moduleMap.get(l.moduleId) : undefined;
}
