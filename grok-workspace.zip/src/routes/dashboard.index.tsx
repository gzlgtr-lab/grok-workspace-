"use client";

import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getDashboard } from "@/lib/progress";
import { firstAvailableLesson, getLesson, COURSES } from "@/lib/curriculum";
import { arabicPercent } from "@/lib/utils";

export const Route = createFileRoute("/dashboard/")({ component: DashHome });

function DashHome() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getDashboard>> | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    getDashboard()
      .then(setData)
      .catch((e: unknown) => setErr(e instanceof Error ? e.message : "تعذّر التحميل"));
  }, []);

  if (err) return <p className="text-danger">{err === "Unauthorized" ? "سجّل الدخول أولًا." : err}</p>;
  if (!data) return <p className="text-muted">جارٍ تجهيز لوحتك…</p>;

  const nextId =
    data.plan && Array.isArray(data.plan.lesson_ids)
      ? (data.plan.lesson_ids as string[]).find((id) => !data.completedLessonIds.includes(id))
      : undefined;
  const next = getLesson(nextId ?? "") ?? firstAvailableLesson();
  const unread = data.notifications.filter((n) => !n.read).length;

  return (
    <div>
      <h1 className="font-display text-3xl">مرحبًا {data.profile.display_name || "طالب العلم"}</h1>
      <p className="mt-1 text-muted">مسارك: {data.profile.goal || "العام"} · المرحلة {data.profile.current_stage}</p>

      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <Stat label="الإنجاز" value={arabicPercent(data.overall.percent)} />
        <Stat label="دروس مكتملة" value={`${data.overall.done} / ${data.overall.total}`} />
        <Stat label="شهادات" value={String(data.certificates.length)} />
      </div>

      {next && (
        <div className="mt-8 rounded-xl border border-border bg-forest-soft/40 p-5">
          <p className="text-sm text-gold">الدرس التالي المقترح</p>
          <h2 className="mt-1 font-display text-2xl">{next.title}</h2>
          <Link
            to="/lessons/$lessonId"
            params={{ lessonId: next.id }}
            className="mt-4 inline-block rounded-md bg-forest px-4 py-2 text-sm text-paper"
          >
            متابعة
          </Link>
        </div>
      )}

      {!data.profile.placement_completed && (
        <Link to="/placement" className="mt-4 block rounded-xl border border-gold/40 bg-gold-soft/40 p-4 text-sm">
          لم تُكمل اختبار تحديد المستوى بعد — ابدأ التشخيص لخطة أدق.
        </Link>
      )}

      <h2 className="mt-10 font-display text-xl">المقررات النشطة</h2>
      <div className="mt-3 grid gap-3 md:grid-cols-2">
        {COURSES.filter((c) => c.stageId === "0" || c.stageId === "1").map((c) => {
          const st = data.courseStats.find((x) => x.id === c.id);
          return (
            <Link key={c.id} to="/courses/$courseId" params={{ courseId: c.id }} className="rounded-xl border border-border p-4">
              <p className="font-medium">{c.title}</p>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-paper-3">
                <div className="h-full bg-forest" style={{ width: `${st?.percent ?? 0}%` }} />
              </div>
              <p className="mt-1 text-xs text-muted">{st?.percent ?? 0}٪</p>
            </Link>
          );
        })}
      </div>

      {unread > 0 && (
        <p className="mt-8 text-sm">
          لديك {unread} إشعارًا — <Link to="/dashboard/notifications">عرض</Link>
        </p>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-border p-4">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-1 font-display text-2xl tabular-nums">{value}</p>
    </div>
  );
}
