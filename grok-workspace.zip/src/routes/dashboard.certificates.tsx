"use client";

import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getDashboard } from "@/lib/progress";

export const Route = createFileRoute("/dashboard/certificates")({ component: CertsPage });

function CertsPage() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getDashboard>> | null>(null);
  useEffect(() => {
    getDashboard().then(setData).catch(() => {});
  }, []);
  if (!data) return <p className="text-muted">جارٍ التحميل…</p>;
  return (
    <div>
      <h1 className="font-display text-3xl">شهاداتي</h1>
      <p className="mt-2 text-sm text-muted">شهادات إتمام تعليمية — ليست إجازة علمية.</p>
      <ul className="mt-6 space-y-3">
        {data.certificates.map((c) => (
          <li key={c.id} className="rounded-xl border border-border p-4">
            <p className="font-medium">{c.title}</p>
            <p className="text-sm text-muted">رمز التحقق: {c.verify_code}</p>
            <div className="mt-2 flex gap-3 text-sm">
              <Link to="/certificates/$id" params={{ id: String(c.id) }} className="text-forest">
                عرض
              </Link>
              <Link to="/verify/$code" params={{ code: c.verify_code }} className="text-forest">
                تحقق عام
              </Link>
            </div>
          </li>
        ))}
      </ul>
      {data.certificates.length === 0 && <p className="mt-8 text-muted">أكمل مقررًا متاحًا لإصدار شهادة.</p>}
    </div>
  );
}
