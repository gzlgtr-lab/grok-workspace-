import { createFileRoute } from "@tanstack/react-router";
import { SiteShell, PageHero } from "@/components/layout/site-shell";

export const Route = createFileRoute("/faq")({ component: Faq });

const ITEMS = [
  ["هل الشهادة إجازة؟", "لا. شهادة إتمام تعليمي تثبت دراسة مقرر، وليست إجازة علمية ولا مؤهلًا جامعيًا."],
  ["هل المنصة تُفتي؟", "لا. المحتوى تعليمي. للمسائل الشخصية راجع عالمًا تثق بعلمه في سياقك."],
  ["هل أبدأ من العقيدة وحدها؟", "التأسيس متوازن: عقيدة وعبادة وقرآن وسنة وسيرة وأخلاق وعربية."],
  ["ماذا لو رسبت في الاختبار؟", "تراجع الدرس وتعيد الاختبار. الانتقال مشروط بعتبة الإتقان."],
  ["هل يلزم مذهب معيّن؟", "طبقة المبتدئ تعرض المتفق عليه. الخلاف يُعرض بقالب علمي في مستواه."],
];

function Faq() {
  return (
    <SiteShell>
      <PageHero kicker="مساعدة" title="أسئلة شائعة" />
      <div className="mx-auto max-w-3xl space-y-3 px-4 py-10">
        {ITEMS.map(([q, a]) => (
          <details key={q} className="rounded-xl border border-border p-4">
            <summary className="cursor-pointer font-medium">{q}</summary>
            <p className="mt-2 text-sm text-ink-soft">{a}</p>
          </details>
        ))}
      </div>
    </SiteShell>
  );
}
