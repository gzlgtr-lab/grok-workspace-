import { createFileRoute, Link } from "@tanstack/react-router";
import { Badge } from "@/components/ui/badge";
import { COURSES, LESSONS, STAGES } from "@/lib/curriculum";

export const Route = createFileRoute("/admin/content")({ component: AdminContent });

function AdminContent() {
  return (
    <div>
      <h1 className="font-display text-3xl">إدارة المحتوى</h1>
      <p className="mt-2 text-sm text-muted">الكتالوج مصدّر من المنهج. الحالات: مسودة / مراجعة / منشور.</p>
      {STAGES.map((s) => (
        <section key={s.id} className="mt-8">
          <h2 className="font-display text-xl">{s.title}</h2>
          <ul className="mt-3 space-y-2">
            {COURSES.filter((c) => c.stageId === s.id).map((c) => {
              const ls = LESSONS.filter((l) => l.courseId === c.id);
              const pub = ls.filter((l) => l.available).length;
              return (
                <li key={c.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border px-3 py-2 text-sm">
                  <Link to="/courses/$courseId" params={{ courseId: c.id }}>
                    {c.title}
                  </Link>
                  <Badge>
                    {pub}/{ls.length} منشور
                  </Badge>
                </li>
              );
            })}
          </ul>
        </section>
      ))}
    </div>
  );
}
