"use client";

import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useTheme } from "@/components/layout/theme";
import { getDashboard, updateProfile, claimAdmin } from "@/lib/progress";

export const Route = createFileRoute("/dashboard/settings")({ component: SettingsPage });

function SettingsPage() {
  const [name, setName] = useState("");
  const [role, setRole] = useState("student");
  const { theme, toggle } = useTheme();

  useEffect(() => {
    getDashboard().then((d) => {
      setName(d.profile.display_name || "");
      setRole(d.role);
    }).catch(() => {});
  }, []);

  return (
    <div>
      <h1 className="font-display text-3xl">الإعدادات</h1>
      <form
        className="mt-6 max-w-md space-y-3"
        onSubmit={async (e) => {
          e.preventDefault();
          await updateProfile({ data: { display_name: name } });
          toast.success("حُفظ الاسم");
        }}
      >
        <label className="block text-sm">
          الاسم الظاهر
          <Input className="mt-1" value={name} onChange={(e) => setName(e.target.value)} />
        </label>
        <Button type="submit">حفظ</Button>
      </form>
      <div className="mt-8">
        <p className="text-sm font-medium">المظهر</p>
        <Button variant="outline" className="mt-2" onClick={toggle}>
          {theme === "dark" ? "وضع نهاري" : "وضع ليلي"}
        </Button>
      </div>
      <p className="mt-8 text-sm text-muted">دورك الحالي: {role}</p>
      {role !== "admin" && (
        <Button
          variant="outline"
          className="mt-3"
          onClick={async () => {
            const r = await claimAdmin();
            setRole(r.role);
            toast.message(r.claimed ? "أصبحت مديرًا لهذه النسخة" : "يوجد مدير مسبقًا");
          }}
        >
          طلب صلاحية الإدارة إن لم تُسند
        </Button>
      )}
      {role === "admin" && (
        <Link to="/admin" className="mt-3 inline-block text-forest">
          فتح لوحة الإدارة
        </Link>
      )}
    </div>
  );
}
