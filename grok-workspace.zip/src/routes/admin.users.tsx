"use client";

import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getAdminStats } from "@/lib/progress";

export const Route = createFileRoute("/admin/users")({ component: AdminUsers });

function AdminUsers() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getAdminStats>> | null>(null);
  useEffect(() => {
    getAdminStats().then(setData).catch(() => {});
  }, []);
  if (!data || data.forbidden) return <p>لا صلاحية أو جارٍ التحميل.</p>;
  return (
    <div>
      <h1 className="font-display text-3xl">المستخدمون</h1>
      <ul className="mt-6 space-y-2">
        {data.recent.map((u) => (
          <li key={u.user_id} className="rounded-lg border border-border px-3 py-2 text-sm">
            <span className="font-medium">{u.display_name || "طالب"}</span>
            <span className="ms-2 text-muted">{u.user_id}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
