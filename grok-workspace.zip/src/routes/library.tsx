"use client";

import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { SiteShell, PageHero } from "@/components/layout/site-shell";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { DOMAIN_LABEL, LEVEL_LABEL, SOURCES, type Domain } from "@/lib/curriculum";

export const Route = createFileRoute("/library")({ component: LibraryPage });

function LibraryPage() {
  const [q, setQ] = useState("");
  const [domain, setDomain] = useState<Domain | "all">("all");
  const list = useMemo(
    () =>
      SOURCES.filter(
        (s) =>
          (domain === "all" || s.domain === domain) &&
          (!q || s.title.includes(q) || s.author.includes(q) || s.description.includes(q)),
      ),
    [q, domain],
  );
  const domains = Array.from(new Set(SOURCES.map((s) => s.domain)));

  return (
    <SiteShell>
      <PageHero kicker="المصادر" title="المكتبة العلمية" subtitle="كل مصدر له بيانات واضحة ويُربط بالدروس. النص الأصلي غير الشرح غير المادة التعليمية." />
      <div className="mx-auto max-w-6xl px-4 py-8">
        <div className="flex flex-col gap-3 sm:flex-row">
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث عن كتاب أو مؤلف…" />
          <select
            className="h-11 rounded-md border border-border bg-paper px-3 text-sm"
            value={domain}
            onChange={(e) => setDomain(e.target.value as Domain | "all")}
          >
            <option value="all">كل العلوم</option>
            {domains.map((d) => (
              <option key={d} value={d}>
                {DOMAIN_LABEL[d]}
              </option>
            ))}
          </select>
        </div>
        {list.length === 0 ? (
          <p className="mt-10 text-center text-muted">لا نتائج بهذه التصفية.</p>
        ) : (
          <div className="mt-8 grid gap-4 md:grid-cols-2">
            {list.map((s) => (
              <Link
                key={s.id}
                to="/library/$sourceId"
                params={{ sourceId: s.id }}
                className="rounded-xl border border-border p-5"
              >
                <div className="flex gap-2">
                  <Badge>{DOMAIN_LABEL[s.domain]}</Badge>
                  <Badge>{LEVEL_LABEL[s.level]}</Badge>
                </div>
                <h2 className="mt-3 font-display text-xl">{s.title}</h2>
                <p className="text-sm text-gold">{s.author}</p>
                <p className="mt-2 text-sm text-ink-soft">{s.description}</p>
              </Link>
            ))}
          </div>
        )}
      </div>
    </SiteShell>
  );
}
