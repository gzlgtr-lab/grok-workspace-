import { createFileRoute, Link } from "@tanstack/react-router";
import { Lock } from "lucide-react";
import { SiteShell, PageHero } from "@/components/layout/site-shell";
import { STAGES, coursesOfStage, lessonsOfCourse } from "@/lib/curriculum";

export const Route = createFileRoute("/tree")({ component: TreePage });

function TreePage() {
  return (
    <SiteShell>
      <PageHero
        kicker="الخريطة"
        title="شجرة التعلم"
        subtitle="مرحلة ← علم ← وحدة ← درس ← اختبار ← إتقان"
      />
      <div className="mx-auto max-w-4xl space-y-10 px-4 py-10">
        {STAGES.map((s) => (
          <section key={s.id}>
            <div className="flex items-center gap-3">
              <span className="size-3 rounded-full bg-gold" />
              <h2 className="font-display text-2xl">{s.title}</h2>
            </div>
            <div className="mr-1.5 mt-4 space-y-4 border-r border-border pr-6">
              {coursesOfStage(s.id).map((c) => (
                <div key={c.id}>
                  <Link to="/courses/$courseId" params={{ courseId: c.id }} className="font-medium text-forest">
                    {c.title}
                  </Link>
                  <ul className="mt-2 space-y-1 text-sm text-ink-soft">
                    {lessonsOfCourse(c.id).map((l) => (
                      <li key={l.id} className="flex items-center gap-2">
                        {!l.available && <Lock className="size-3 text-muted" />}
                        <Link to="/lessons/$lessonId" params={{ lessonId: l.id }} className="hover:text-forest">
                          {l.title}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </section>
        ))}
      </div>
    </SiteShell>
  );
}
