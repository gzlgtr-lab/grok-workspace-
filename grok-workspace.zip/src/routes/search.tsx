"use client";

import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState, type ReactNode } from "react";
import { SiteShell, PageHero } from "@/components/layout/site-shell";
import { Input } from "@/components/ui/input";
import { searchCatalog } from "@/lib/curriculum";

export const Route = createFileRoute("/search")({ component: SearchPage });

function SearchPage() {
  const [q, setQ] = useState("");
  const res = useMemo(() => searchCatalog(q), [q]);
  return (
    <SiteShell>
      <PageHero kicker="بحث" title="البحث في الأكاديمية" />
      <div className="mx-auto max-w-3xl px-4 py-8">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="درس، مقرر، مصطلح، كتاب…" autoFocus />
        {!q && <p className="mt-8 text-sm text-muted">ابدأ بالكتابة للبحث في الدروس والمقررات والمصادر.</p>}
        {q && (
          <div className="mt-8 space-y-8">
            <Block title="مقررات">
              {res.courses.map((c) => (
                <Link key={c.id} to="/courses/$courseId" params={{ courseId: c.id }} className="block py-2">
                  {c.title}
                </Link>
              ))}
            </Block>
            <Block title="دروس">
              {res.lessons.map((l) => (
                <Link key={l.id} to="/lessons/$lessonId" params={{ lessonId: l.id }} className="block py-2">
                  {l.title}
                </Link>
              ))}
            </Block>
            <Block title="مصادر">
              {res.sources.map((s) => (
                <Link key={s.id} to="/library/$sourceId" params={{ sourceId: s.id }} className="block py-2">
                  {s.title}
                </Link>
              ))}
            </Block>
          </div>
        )}
      </div>
    </SiteShell>
  );
}

function Block({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section>
      <h2 className="text-sm text-gold">{title}</h2>
      <div className="mt-2 text-sm">{children}</div>
    </section>
  );
}
