import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Check, GraduationCap, Library, Route as RouteIcon, Trees } from "lucide-react";
import { SiteShell } from "@/components/layout/site-shell";
import { Button } from "@/components/ui/button";
import { academyStats, STAGES, TRACKS, COURSES } from "@/lib/curriculum";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const stats = academyStats();
  const featured = COURSES.filter((c) =>
    ["aqidah-basic", "fiqh-ibadat-beginner", "seerah-brief", "quran-reading"].includes(c.id),
  );

  return (
    <SiteShell>
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 opacity-40">
          <GeometricField />
        </div>
        <div className="relative mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:py-24 lg:grid-cols-2 lg:items-center">
          <div>
            <p className="text-sm text-gold">أكاديمية رقمية · منهج جامعي</p>
            <h1 className="mt-3 font-display text-4xl leading-tight sm:text-5xl">
              علوم إسلامية من الصفر
              <span className="block text-forest">إلى مقام الباحث</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg text-ink-soft">
              ليست موسوعة ولا صفحات معلومات. مسار هرمي: مرحلة، علم، مقرر، وحدة، درس، اختبار، إتقان، ثم انتقال.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg">
                <Link to="/lessons/$lessonId" params={{ lessonId: "l-islam-1" }}>
                  ابدأ من الصفر
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/placement">اختبار تحديد المستوى</Link>
              </Button>
            </div>
            <p className="mt-4 text-sm text-muted">دراسة المقررات لا تعني التأهل للإفتاء أو الإجازة العلمية.</p>
          </div>
          <div className="ornament-border rounded-xl p-6">
            <p className="text-sm text-gold">كيف تسير</p>
            <ol className="mt-4 space-y-4">
              {[
                "تهيئة واختبار تشخيصي متعدد المهارات",
                "خطة شخصية بحسب هدفك ووقتك",
                "درس بثلاث طبقات: مبسط ومتوسط ومتقدم",
                "إتقان قبل فتح المقرر التالي",
              ].map((t, i) => (
                <li key={t} className="flex gap-3">
                  <span className="grid size-8 shrink-0 place-items-center rounded-full bg-forest text-sm text-paper">
                    {i + 1}
                  </span>
                  <span className="pt-1 text-sm">{t}</span>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      <section className="border-y border-border bg-paper-2/50">
        <div className="mx-auto grid max-w-6xl grid-cols-2 gap-6 px-4 py-8 sm:grid-cols-4">
          {[
            [stats.stages, "مراحل"],
            [stats.tracks, "مسارات"],
            [stats.courses, "مقررات"],
            [stats.availableLessons, "دروس مكتملة المحتوى"],
          ].map(([n, l]) => (
            <div key={String(l)}>
              <p className="font-display text-3xl text-forest tabular-nums">{n}</p>
              <p className="text-sm text-muted">{l}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="text-sm text-gold">المراحل التعليمية</p>
            <h2 className="mt-1 font-display text-3xl">من التهيئة إلى البحث</h2>
          </div>
          <Link to="/stages" className="text-sm text-forest">
            عرض الكل
          </Link>
        </div>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {STAGES.map((s) => (
            <Link
              key={s.id}
              to="/stages/$stageId"
              params={{ stageId: s.id }}
              className="paper-card rounded-xl border border-border p-5 transition-transform duration-150 hover:-translate-y-0.5"
            >
              <p className="text-xs text-gold">{s.subtitle}</p>
              <h3 className="mt-1 font-display text-xl">{s.title}</h3>
              <p className="mt-2 text-sm text-ink-soft">{s.goal}</p>
              <p className="mt-4 text-xs text-muted">{s.duration}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="bg-forest text-paper">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <p className="text-sm text-gold-soft">المسارات</p>
          <h2 className="mt-1 font-display text-3xl">اختر هدفك لا مجرد علم</h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {TRACKS.slice(0, 6).map((t) => (
              <Link
                key={t.id}
                to="/tracks/$trackId"
                params={{ trackId: t.id }}
                className="rounded-xl border border-paper/15 bg-forest-deep/40 p-5 hover:bg-forest-deep/70"
              >
                <h3 className="font-display text-xl">{t.title}</h3>
                <p className="mt-1 text-xs text-gold-soft">{t.audience}</p>
                <p className="mt-3 text-sm text-paper/80">{t.description}</p>
              </Link>
            ))}
          </div>
          <Link to="/tracks" className="mt-6 inline-flex items-center gap-1 text-sm text-gold-soft">
            كل المسارات <ArrowLeft className="size-4" />
          </Link>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <p className="text-sm text-gold">المسار العام للمبتدئ</p>
        <h2 className="mt-1 font-display text-3xl">مقررات تُقرأ اليوم</h2>
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          {featured.map((c) => (
            <Link
              key={c.id}
              to="/courses/$courseId"
              params={{ courseId: c.id }}
              className="paper-card flex flex-col rounded-xl border border-border p-5"
            >
              <h3 className="font-display text-xl">{c.title}</h3>
              <p className="mt-2 flex-1 text-sm text-ink-soft">{c.description}</p>
              <p className="mt-4 text-xs text-muted">{c.hours} ساعة تقديرية</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-8">
        <div className="grid gap-6 lg:grid-cols-4">
          {[
            { icon: Trees, t: "شجرة تعلم", d: "مرحلة ثم علم ثم وحدة ثم درس." },
            { icon: GraduationCap, t: "إتقان", d: "لا انتقال بمجرد الفتح." },
            { icon: Library, t: "مكتبة", d: "مصادر مربوطة بالدروس." },
            { icon: RouteIcon, t: "متطلبات", d: "لا قفز إلى التخريج قبل المصطلح." },
          ].map((x) => (
            <div key={x.t} className="rounded-xl border border-border p-5">
              <x.icon className="size-5 text-forest" />
              <h3 className="mt-3 font-medium">{x.t}</h3>
              <p className="mt-1 text-sm text-muted">{x.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-12">
        <div className="rounded-xl bg-gold-soft/60 p-8 sm:p-10">
          <h2 className="font-display text-3xl">قالب الخلاف العلمي</h2>
          <ul className="mt-4 grid gap-2 text-sm sm:grid-cols-2">
            {[
              "تصوير المسألة",
              "محل الاتفاق ثم الخلاف",
              "الأقوال والأدلة",
              "سبب الاختلاف",
              "الخلاصة التعليمية",
              "تنبيه: ليست فتوى",
            ].map((t) => (
              <li key={t} className="flex items-center gap-2">
                <Check className="size-4 text-forest" /> {t}
              </li>
            ))}
          </ul>
        </div>
      </section>
    </SiteShell>
  );
}

function GeometricField() {
  return (
    <svg className="h-full w-full" viewBox="0 0 800 600" aria-hidden="true">
      <g fill="none" stroke="currentColor" className="text-forest" strokeWidth="0.6" opacity="0.35">
        {Array.from({ length: 8 }).map((_, i) => (
          <polygon
            key={i}
            points="400,80 520,180 520,340 400,440 280,340 280,180"
            transform={`rotate(${i * 22.5} 400 300) scale(${1 - i * 0.08})`}
            transform-origin="400 300"
            transform-origin="400 300"
          />
        ))}
      </g>
    </svg>
  );
}
