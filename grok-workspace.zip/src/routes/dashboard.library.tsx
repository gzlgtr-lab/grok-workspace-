"use client";

import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getLesson } from "@/lib/curriculum";
import { getDashboard } from "@/lib/progress";

export const Route = createFileRoute("/dashboard/library")({ component: MyLib });

function MyLib() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getDashboard>> | null>(null);
  useEffect(() => {
    getDashboard().then(setData).catch(() => {});
  }, []);
  if (!data) return <p className="text-muted">جارٍ التحميل…</p>;
  return (
    <div>
      <h1 className="font-display text-3xl">مكتبتي الشخصية</h1>
      <p className="mt-2 text-sm text-muted">الدروس المحفوظة.</p>
      <ul className="mt-6 space-y-2">
        {data.bookmarks.map((id) => (
          <li key={id}>
            <Link to="/lessons/$lessonId" params={{ lessonId: id }} className="text-forest">
              {getLesson(id)?.title ?? id}
            </Link>
          </li>
        ))}
      </ul>
      {data.bookmarks.length === 0 && <p className="mt-8 text-muted">لم تحفظ دروسًا بعد.</p>}
    </div>
  );
}
