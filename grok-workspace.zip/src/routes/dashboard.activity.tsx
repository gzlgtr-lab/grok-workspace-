"use client";

import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getDashboard } from "@/lib/progress";

export const Route = createFileRoute("/dashboard/activity")({ component: ActivityPage });

function ActivityPage() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getDashboard>> | null>(null);
  useEffect(() => {
    getDashboard().then(setData).catch(() => {});
  }, []);
  if (!data) return <p className="text-muted">جارٍ التحميل…</p>;
  return (
    <div>
      <h1 className="font-display text-3xl">سجل النشاط</h1>
      <h2 className="mt-6 text-sm text-gold">الاختبارات</h2>
      <ul className="mt-2 space-y-2 text-sm">
        {data.attempts.map((a) => (
          <li key={a.id} className="rounded-lg border border-border px-3 py-2">
            {a.quiz_id} · {a.percent}٪ · {a.passed ? "نجاح" : "إعادة"}
          </li>
        ))}
      </ul>
      {data.attempts.length === 0 && <p className="mt-4 text-muted">لا محاولات بعد.</p>}
    </div>
  );
}
