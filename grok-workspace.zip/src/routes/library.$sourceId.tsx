import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { SiteShell, PageHero } from "@/components/layout/site-shell";
import { Badge } from "@/components/ui/badge";
import { DOMAIN_LABEL, getCourse, getSource } from "@/lib/curriculum";

export const Route = createFileRoute("/library/$sourceId")({ component: SourcePage });

function SourcePage() {
  const { sourceId } = Route.useParams();
  const s = getSource(sourceId);
  if (!s) throw notFound();
  return (
    <SiteShell>
      <PageHero kicker={s.author} title={s.title} subtitle={s.description} />
      <div className="mx-auto max-w-3xl space-y-4 px-4 py-10">
        <div className="flex flex-wrap gap-2">
          <Badge>{DOMAIN_LABEL[s.domain]}</Badge>
          <Badge>{s.kind}</Badge>
          <Badge>{s.era}</Badge>
          <Badge>{s.importance === "core" ? "أساسي" : s.importance === "advanced" ? "متقدم" : "مساعد"}</Badge>
        </div>
        <h2 className="font-display text-xl">مقررات مرتبطة</h2>
        <ul className="space-y-2">
          {s.relatedCourseIds.map((id) => {
            const c = getCourse(id);
            return c ? (
              <li key={id}>
                <Link className="text-forest" to="/courses/$courseId" params={{ courseId: id }}>
                  {c.title}
                </Link>
              </li>
            ) : null;
          })}
        </ul>
      </div>
    </SiteShell>
  );
}
