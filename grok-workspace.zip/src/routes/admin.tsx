import { createFileRoute, Link, Outlet } from "@tanstack/react-router";
import { SiteHeader } from "@/components/layout/site-shell";
import { RequireAuth } from "@/components/layout/site-shell";

export const Route = createFileRoute("/admin")({ component: AdminLayout });

function AdminLayout() {
  return (
    <RequireAuth>
      <div className="min-h-screen bg-paper text-ink">
        <SiteHeader />
        <div className="mx-auto flex max-w-6xl gap-8 px-4 py-8">
          <aside className="hidden w-48 shrink-0 text-sm sm:block">
            <p className="mb-3 text-xs text-gold">الإدارة</p>
            <nav className="flex flex-col gap-2">
              <Link to="/admin">الإحصاءات</Link>
              <Link to="/admin/users">المستخدمون</Link>
              <Link to="/admin/content">المحتوى</Link>
            </nav>
          </aside>
          <div className="min-w-0 flex-1">
            <Outlet />
          </div>
        </div>
      </div>
    </RequireAuth>
  );
}
