import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteShell, PageHero } from "@/components/layout/site-shell";
import { TRACKS } from "@/lib/curriculum";

export const Route = createFileRoute("/tracks")({ component: TracksPage });

function TracksPage() {
  return (
    <SiteShell>
      <PageHero kicker="الأهداف" title="المسارات" subtitle="المسار العام، طالب العلم، المعلم، الباحث، ثم التخصصات." />
      <div className="mx-auto grid max-w-6xl gap-4 px-4 py-10 sm:grid-cols-2 lg:grid-cols-3">
        {TRACKS.map((t) => (
          <Link
            key={t.id}
            to="/tracks/$trackId"
            params={{ trackId: t.id }}
            className="paper-card rounded-xl border border-border p-5"
          >
            <h2 className="font-display text-xl">{t.title}</h2>
            <p className="mt-1 text-xs text-gold">{t.audience}</p>
            <p className="mt-3 text-sm text-ink-soft">{t.description}</p>
            <p className="mt-4 text-xs text-muted">{t.courseIds.length} مقررات</p>
          </Link>
        ))}
      </div>
    </SiteShell>
  );
}
