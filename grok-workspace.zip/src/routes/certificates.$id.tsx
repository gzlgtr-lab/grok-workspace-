"use client";

import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Logo } from "@/components/brand/logo";
import { getMyCertificate } from "@/lib/progress";
import { useCurrentUser } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/certificates/$id")({ component: CertView });

function CertView() {
  const { id } = Route.useParams();
  const user = useCurrentUser();
  const [row, setRow] = useState<Awaited<ReturnType<typeof getMyCertificate>> | null>(null);
  useEffect(() => {
    getMyCertificate({ data: { id: Number(id) } }).then(setRow).catch(() => setRow(null));
  }, [id]);
  if (!row) return <p className="p-10 text-muted">جارٍ التحميل أو لا صلاحية.</p>;
  return (
    <main className="min-h-screen bg-paper px-4 py-10 text-ink">
      <div className="ornament-border mx-auto max-w-3xl rounded-xl p-10 text-center">
        <Logo />
        <p className="mt-6 text-sm text-gold">شهادة إتمام تعليمية</p>
        <h1 className="mt-2 font-display text-4xl">{row.title}</h1>
        <p className="mt-6 text-lg">{user?.displayName ?? "طالب"}</p>
        <p className="mt-4 max-w-md mx-auto text-sm text-muted">
          أتمّ المقرر في أكاديمية العلم. هذه الوثيقة تعليمية ولا تُعد إجازة علمية ولا تأهيلًا للإفتاء.
        </p>
        <p className="mt-8 text-xs tabular-nums text-muted">رمز التحقق: {row.verify_code}</p>
        <button type="button" className="mt-6 text-sm text-forest print:hidden" onClick={() => window.print()}>
          طباعة
        </button>
      </div>
    </main>
  );
}
