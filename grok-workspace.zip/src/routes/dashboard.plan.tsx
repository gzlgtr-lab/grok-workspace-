"use client";

import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { TRACKS, getLesson } from "@/lib/curriculum";
import { saveStudyPlan } from "@/lib/progress";

export const Route = createFileRoute("/dashboard/plan")({ component: PlanPage });

function PlanPage() {
  const [kind, setKind] = useState("general");
  const [minutes, setMinutes] = useState(30);
  const [ids, setIds] = useState<string[] | null>(null);
  const [busy, setBusy] = useState(false);

  return (
    <div>
      <h1 className="font-display text-3xl">خطتي التعليمية</h1>
      <p className="mt-2 text-sm text-muted">تُولَّد من هدفك ووقتك وما أنجزته.</p>
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <label className="text-sm">
          الهدف
          <select
            className="mt-1 h-11 w-full rounded-md border border-border bg-paper px-3"
            value={kind}
            onChange={(e) => setKind(e.target.value)}
          >
            {TRACKS.map((t) => (
              <option key={t.id} value={t.id}>
                {t.title}
              </option>
            ))}
          </select>
        </label>
        <label className="text-sm">
          دقائق في اليوم
          <select
            className="mt-1 h-11 w-full rounded-md border border-border bg-paper px-3"
            value={minutes}
            onChange={(e) => setMinutes(Number(e.target.value))}
          >
            {[15, 30, 60, 90].map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </label>
      </div>
      <Button
        className="mt-4"
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          const r = await saveStudyPlan({ data: { kind, minutes } });
          setIds(r.lessonIds);
          setBusy(false);
        }}
      >
        توليد الخطة
      </Button>
      {ids && (
        <ol className="mt-8 space-y-2">
          {ids.map((id, i) => {
            const l = getLesson(id);
            return (
              <li key={id} className="rounded-lg border border-border p-3 text-sm">
                {i + 1}.{" "}
                {l ? (
                  <Link to="/lessons/$lessonId" params={{ lessonId: id }} className="text-forest">
                    {l.title}
                  </Link>
                ) : (
                  id
                )}
              </li>
            );
          })}
        </ol>
      )}
    </div>
  );
}
