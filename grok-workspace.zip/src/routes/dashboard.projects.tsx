"use client";

import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { getDashboard, saveProject } from "@/lib/progress";

export const Route = createFileRoute("/dashboard/projects")({ component: ProjectsPage });

function ProjectsPage() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getDashboard>> | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  useEffect(() => {
    getDashboard().then(setData).catch(() => {});
  }, []);
  return (
    <div>
      <h1 className="font-display text-3xl">المشاريع والبحوث</h1>
      <form
        className="mt-6 space-y-3 rounded-xl border border-border p-5"
        onSubmit={async (e) => {
          e.preventDefault();
          await saveProject({ data: { title, description } });
          toast.success("سُلّم المشروع");
          setTitle("");
          setDescription("");
          setData(await getDashboard());
        }}
      >
        <Input required value={title} onChange={(e) => setTitle(e.target.value)} placeholder="عنوان المشروع" />
        <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="وصف أو إشكالية البحث" />
        <Button type="submit">تسليم</Button>
      </form>
      <ul className="mt-8 space-y-3">
        {data?.projects.map((p) => (
          <li key={p.id} className="rounded-xl border border-border p-4">
            <p className="font-medium">{p.title}</p>
            <p className="text-sm text-muted">{p.status}</p>
            {p.description && <p className="mt-2 text-sm">{p.description}</p>}
          </li>
        ))}
      </ul>
    </div>
  );
}
