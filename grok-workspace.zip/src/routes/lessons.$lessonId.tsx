import { createFileRoute, notFound } from "@tanstack/react-router";
import { LessonView } from "@/components/lesson/lesson-view";
import { SiteShell } from "@/components/layout/site-shell";
import { getLesson } from "@/lib/curriculum";

export const Route = createFileRoute("/lessons/$lessonId")({ component: LessonPage });

function LessonPage() {
  const { lessonId } = Route.useParams();
  const lesson = getLesson(lessonId);
  if (!lesson) throw notFound();
  return (
    <SiteShell>
      <LessonView lesson={lesson} />
    </SiteShell>
  );
}
