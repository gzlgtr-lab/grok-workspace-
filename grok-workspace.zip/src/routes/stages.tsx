import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteShell, PageHero } from "@/components/layout/site-shell";
import { STAGES, coursesOfStage } from "@/lib/curriculum";

export const Route = createFileRoute("/stages")({ component: StagesPage });

function StagesPage() {
  return (
    <SiteShell>
      <PageHero kicker="المنهج" title="المراحل التعليمية" subtitle="كل مرحلة تُغلق بتصور واضح قبل التي تليها." />
      <div className="mx-auto max-w-6xl space-y-4 px-4 py-10">
        {STAGES.map((s) => (
          <Link
            key={s.id}
            to="/stages/$stageId"
            params={{ stageId: s.id }}
            className="paper-card block rounded-xl border border-border p-6"
          >
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <h2 className="font-display text-2xl">{s.title}</h2>
              <span className="text-sm text-muted">{coursesOfStage(s.id).length} مقررات · {s.duration}</span>
            </div>
            <p className="mt-2 text-ink-soft">{s.goal}</p>
          </Link>
        ))}
      </div>
    </SiteShell>
  );
}
