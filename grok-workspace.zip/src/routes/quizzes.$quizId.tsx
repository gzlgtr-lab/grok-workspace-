import { createFileRoute } from "@tanstack/react-router";
import { QuizRunner } from "@/components/quiz/quiz-runner";
import { SiteShell } from "@/components/layout/site-shell";

export const Route = createFileRoute("/quizzes/$quizId")({ component: QuizPage });

function QuizPage() {
  const { quizId } = Route.useParams();
  return (
    <SiteShell>
      <QuizRunner quizId={quizId} />
    </SiteShell>
  );
}
