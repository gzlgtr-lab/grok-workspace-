import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { SiteShell, PageHero } from "@/components/layout/site-shell";
import { Badge } from "@/components/ui/badge";
import { DOMAIN_LABEL, LEVEL_LABEL, getCourse, getSource, lessonsOfModule, modulesOf } from "@/lib/curriculum";
import { formatHours } from "@/lib/utils";

export const Route = createFileRoute("/courses/$courseId")({ component: CoursePage });

function CoursePage() {
  const { courseId } = Route.useParams();
  const course = getCourse(courseId);
  if (!course) throw notFound();
  const modules = modulesOf(course.id);
  const first = modules.flatMap((m) => lessonsOfModule(m.id)).find((l) => l.available);

  return (
    <SiteShell>
      <PageHero
        kicker={`${DOMAIN_LABEL[course.domain]} · ${LEVEL_LABEL[course.level]}`}
        title={course.title}
        subtitle={course.description}
        actions={
          first ? (
            <Link
              to="/lessons/$lessonId"
              params={{ lessonId: first.id }}
              className="rounded-md bg-forest px-5 py-2.5 text-sm text-paper"
            >
              بدء المقرر
            </Link>
          ) : null
        }
      />
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-10 lg:grid-cols-[2fr_1fr]">
        <div className="space-y-8">
          <section>
            <h2 className="font-display text-2xl">الأهداف</h2>
            <ul className="mt-3 list-disc pr-5 text-sm text-ink-soft">
              {course.objectives.map((o) => (
                <li key={o}>{o}</li>
              ))}
            </ul>
          </section>
          {course.prerequisites.length > 0 && (
            <section>
              <h2 className="font-display text-2xl">المتطلبات السابقة</h2>
              <ul className="mt-3 space-y-2">
                {course.prerequisites.map((id) => {
                  const c = getCourse(id);
                  return c ? (
                    <li key={id}>
                      <Link className="text-forest" to="/courses/$courseId" params={{ courseId: id }}>
                        {c.title}
                      </Link>
                    </li>
                  ) : null;
                })}
              </ul>
            </section>
          )}
          <section className="space-y-4">
            {modules.map((m) => (
              <div key={m.id} className="rounded-xl border border-border p-5">
                <h3 className="font-display text-xl">{m.title}</h3>
                <p className="text-sm text-muted">{m.summary}</p>
                <ol className="mt-3 space-y-1 text-sm">
                  {lessonsOfModule(m.id).map((l, i) => (
                    <li key={l.id}>
                      <Link to="/lessons/$lessonId" params={{ lessonId: l.id }}>
                        {i + 1}. {l.title}
                        {!l.available ? " — يُفتح لاحقًا" : ""}
                      </Link>
                    </li>
                  ))}
                </ol>
              </div>
            ))}
          </section>
        </div>
        <aside className="space-y-4">
          <div className="rounded-xl border border-border p-5">
            <p className="text-sm text-muted">المدة التقديرية</p>
            <p className="font-display text-2xl">{formatHours(course.hours)}</p>
            <Badge className="mt-3">{LEVEL_LABEL[course.level]}</Badge>
          </div>
          {course.sources.length > 0 && (
            <div className="rounded-xl border border-border p-5">
              <p className="text-sm font-medium">مصادر</p>
              <ul className="mt-2 space-y-1 text-sm">
                {course.sources.map((id) => {
                  const s = getSource(id);
                  return s ? (
                    <li key={id}>
                      <Link to="/library/$sourceId" params={{ sourceId: id }} className="text-forest">
                        {s.title}
                      </Link>
                    </li>
                  ) : (
                    <li key={id}>{id}</li>
                  );
                })}
              </ul>
            </div>
          )}
        </aside>
      </div>
    </SiteShell>
  );
}
