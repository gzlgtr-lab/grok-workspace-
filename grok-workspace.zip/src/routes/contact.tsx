"use client";

import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { SiteShell, PageHero } from "@/components/layout/site-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/contact")({ component: Contact });

function Contact() {
  const [sent, setSent] = useState(false);
  return (
    <SiteShell>
      <PageHero kicker="تواصل" title="راسل الأكاديمية" subtitle="للملاحظات العلمية والتقنية. ليست قناة فتوى." />
      <form
        className="mx-auto max-w-lg space-y-3 px-4 py-10"
        onSubmit={(e) => {
          e.preventDefault();
          setSent(true);
          toast.success("وصلت رسالتك في هذه النسخة التجريبية.");
        }}
      >
        <Input required placeholder="الاسم" />
        <Input required type="email" placeholder="البريد" dir="ltr" />
        <Textarea required placeholder="الرسالة" />
        <Button type="submit">إرسال</Button>
        {sent && <p className="text-sm text-success">شكرًا. في النسخة الكاملة تُراجع الرسائل من المشرف العلمي.</p>}
      </form>
    </SiteShell>
  );
}
