"use client";

import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getDashboard } from "@/lib/progress";

export const Route = createFileRoute("/dashboard/skills")({ component: SkillsPage });

function SkillsPage() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getDashboard>> | null>(null);
  useEffect(() => {
    getDashboard().then(setData).catch(() => {});
  }, []);
  if (!data) return <p className="text-muted">جارٍ التحميل…</p>;
  const entries = Object.entries(data.skills);
  return (
    <div>
      <h1 className="font-display text-3xl">خريطة المهارات</h1>
      <p className="mt-2 text-sm text-muted">نسبة إكمال الدروس المتاحة في كل علم.</p>
      <div className="mt-8 space-y-4">
        {entries.length === 0 && <p className="text-muted">ابدأ درسًا لبناء الخريطة.</p>}
        {entries.map(([k, v]) => {
          const pct = v.total ? Math.round((v.score / v.total) * 100) : 0;
          return (
            <div key={k}>
              <div className="flex justify-between text-sm">
                <span>{v.label}</span>
                <span className="tabular-nums text-muted">{pct}٪</span>
              </div>
              <div className="mt-1 h-2 overflow-hidden rounded-full bg-paper-3">
                <div className="h-full bg-forest" style={{ width: `${pct}%` }} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
