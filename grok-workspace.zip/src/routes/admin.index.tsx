"use client";

import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { claimAdmin, getAdminStats } from "@/lib/progress";

export const Route = createFileRoute("/admin/")({ component: AdminHome });

function AdminHome() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getAdminStats>> | null>(null);
  useEffect(() => {
    getAdminStats().then(setData).catch(() => {});
  }, []);
  if (!data) return <p className="text-muted">جارٍ التحميل…</p>;
  if (data.forbidden) {
    return (
      <div>
        <h1 className="font-display text-2xl">لا صلاحية</h1>
        <p className="mt-2 text-sm text-muted">دورك: {data.role}. إن لم يوجد مدير بعد يمكنك المطالبة بالصلاحية.</p>
        <Button
          className="mt-4"
          onClick={async () => {
            await claimAdmin();
            setData(await getAdminStats());
          }}
        >
          المطالبة إن كانت شاغرة
        </Button>
      </div>
    );
  }
  return (
    <div>
      <h1 className="font-display text-3xl">إحصاءات الأكاديمية</h1>
      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <Card l="طلاب" v={data.users} />
        <Card l="محاولات اختبار" v={data.attempts} />
        <Card l="شهادات" v={data.certs} />
        <Card l="دروس متاحة" v={data.catalog.available} />
      </div>
      <h2 className="mt-10 font-display text-xl">أحدث التسجيلات</h2>
      <ul className="mt-3 space-y-2 text-sm">
        {data.recent.map((u) => (
          <li key={u.user_id} className="rounded-lg border border-border px-3 py-2">
            {u.display_name || u.user_id}
          </li>
        ))}
      </ul>
    </div>
  );
}

function Card({ l, v }: { l: string; v: number }) {
  return (
    <div className="rounded-xl border border-border p-4">
      <p className="text-xs text-muted">{l}</p>
      <p className="font-display text-2xl tabular-nums">{v}</p>
    </div>
  );
}
