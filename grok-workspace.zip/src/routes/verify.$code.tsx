"use client";

import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteShell, PageHero } from "@/components/layout/site-shell";
import { verifyCertificate } from "@/lib/progress";

export const Route = createFileRoute("/verify/$code")({ component: VerifyPage });

function VerifyPage() {
  const { code } = Route.useParams();
  const [row, setRow] = useState<Awaited<ReturnType<typeof verifyCertificate>> | undefined>(undefined);
  useEffect(() => {
    verifyCertificate({ data: { code } }).then(setRow);
  }, [code]);
  return (
    <SiteShell>
      <PageHero kicker="تحقق" title="التحقق من الشهادة" subtitle={code} />
      <div className="mx-auto max-w-lg px-4 py-10">
        {row === undefined && <p className="text-muted">جارٍ التحقق…</p>}
        {row === null && <p className="text-danger">لا شهادة بهذا الرمز.</p>}
        {row && (
          <div className="rounded-xl border border-border p-6">
            <p className="font-display text-2xl">{row.title}</p>
            <p className="mt-2 text-sm text-muted">شهادة إتمام تعليمية — ليست إجازة.</p>
            <p className="mt-4 text-sm">الدرجة: {row.score ?? "—"} · الساعات: {row.hours ?? "—"}</p>
          </div>
        )}
      </div>
    </SiteShell>
  );
}
