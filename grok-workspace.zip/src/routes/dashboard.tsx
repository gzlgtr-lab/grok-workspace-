import { createFileRoute, Outlet } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/app-shell";

export const Route = createFileRoute("/dashboard")({ component: DashLayout });

function DashLayout() {
  return (
    <AppShell>
      <Outlet />
    </AppShell>
  );
}
