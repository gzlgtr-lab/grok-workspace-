import { createFileRoute } from "@tanstack/react-router";
import { QuizRunner } from "@/components/quiz/quiz-runner";
import { SiteShell, PageHero } from "@/components/layout/site-shell";

export const Route = createFileRoute("/placement")({ component: Placement });

function Placement() {
  return (
    <SiteShell>
      <PageHero
        kicker="تشخيص"
        title="اختبار تحديد المستوى"
        subtitle="لا درجة واحدة: تقرير متعدد المهارات يوجه خطتك. سجّل الدخول لحفظ النتيجة."
      />
      <QuizRunner quizId="placement" />
    </SiteShell>
  );
}
