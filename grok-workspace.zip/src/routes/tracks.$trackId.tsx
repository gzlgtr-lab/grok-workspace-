import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { SiteShell, PageHero } from "@/components/layout/site-shell";
import { getCourse, getTrack } from "@/lib/curriculum";

export const Route = createFileRoute("/tracks/$trackId")({ component: TrackDetail });

function TrackDetail() {
  const { trackId } = Route.useParams();
  const track = getTrack(trackId);
  if (!track) throw notFound();
  return (
    <SiteShell>
      <PageHero kicker={track.audience} title={track.title} subtitle={track.description} />
      <ol className="mx-auto max-w-3xl space-y-3 px-4 py-10">
        {track.courseIds.map((id, i) => {
          const c = getCourse(id);
          if (!c) return null;
          return (
            <li key={id}>
              <Link
                to="/courses/$courseId"
                params={{ courseId: id }}
                className="flex gap-4 rounded-xl border border-border p-4"
              >
                <span className="grid size-8 place-items-center rounded-full bg-forest text-sm text-paper">
                  {i + 1}
                </span>
                <span>
                  <span className="block font-medium">{c.title}</span>
                  <span className="text-sm text-muted">{c.description}</span>
                </span>
              </Link>
            </li>
          );
        })}
      </ol>
    </SiteShell>
  );
}
