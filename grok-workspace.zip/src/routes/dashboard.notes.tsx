"use client";

import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getLesson } from "@/lib/curriculum";
import { getDashboard } from "@/lib/progress";

export const Route = createFileRoute("/dashboard/notes")({ component: NotesPage });

function NotesPage() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getDashboard>> | null>(null);
  useEffect(() => {
    getDashboard().then(setData).catch(() => {});
  }, []);
  if (!data) return <p className="text-muted">جارٍ التحميل…</p>;
  return (
    <div>
      <h1 className="font-display text-3xl">ملاحظاتي</h1>
      <ul className="mt-6 space-y-3">
        {data.notes.map((n) => (
          <li key={n.id} className="rounded-xl border border-border p-4 text-sm">
            <Link to="/lessons/$lessonId" params={{ lessonId: n.lesson_id }} className="text-gold">
              {getLesson(n.lesson_id)?.title ?? n.lesson_id}
            </Link>
            <p className="mt-2 whitespace-pre-wrap">{n.body}</p>
          </li>
        ))}
      </ul>
      {data.notes.length === 0 && <p className="mt-8 text-muted">لا ملاحظات بعد. أضفها من صفحة الدرس.</p>}
    </div>
  );
}
