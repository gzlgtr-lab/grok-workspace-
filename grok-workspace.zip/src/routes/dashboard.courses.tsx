"use client";

import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { COURSES } from "@/lib/curriculum";
import { getDashboard } from "@/lib/progress";

export const Route = createFileRoute("/dashboard/courses")({ component: MyCourses });

function MyCourses() {
  const [stats, setStats] = useState<Awaited<ReturnType<typeof getDashboard>> | null>(null);
  useEffect(() => {
    getDashboard().then(setStats).catch(() => setStats(null));
  }, []);
  return (
    <div>
      <h1 className="font-display text-3xl">مقرراتي</h1>
      <div className="mt-6 grid gap-3">
        {COURSES.map((c) => {
          const st = stats?.courseStats.find((x) => x.id === c.id);
          return (
            <Link key={c.id} to="/courses/$courseId" params={{ courseId: c.id }} className="rounded-xl border border-border p-4">
              <div className="flex justify-between gap-3">
                <p className="font-medium">{c.title}</p>
                <span className="text-sm text-muted">{st?.percent ?? 0}٪</span>
              </div>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-paper-3">
                <div className="h-full bg-forest" style={{ width: `${st?.percent ?? 0}%` }} />
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
