import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { SiteShell, PageHero } from "@/components/layout/site-shell";
import { Badge } from "@/components/ui/badge";
import { LEVEL_LABEL, coursesOfStage, getStage } from "@/lib/curriculum";

export const Route = createFileRoute("/stages/$stageId")({ component: StageDetail });

function StageDetail() {
  const { stageId } = Route.useParams();
  const stage = getStage(stageId);
  if (!stage) throw notFound();
  const courses = coursesOfStage(stage.id);
  return (
    <SiteShell>
      <PageHero kicker={stage.subtitle} title={stage.title} subtitle={stage.goal} />
      <div className="mx-auto grid max-w-6xl gap-4 px-4 py-10 md:grid-cols-2">
        {courses.map((c) => (
          <Link
            key={c.id}
            to="/courses/$courseId"
            params={{ courseId: c.id }}
            className="rounded-xl border border-border p-5"
          >
            <Badge>{LEVEL_LABEL[c.level]}</Badge>
            <h2 className="mt-3 font-display text-xl">{c.title}</h2>
            <p className="mt-2 text-sm text-ink-soft">{c.description}</p>
          </Link>
        ))}
      </div>
    </SiteShell>
  );
}
