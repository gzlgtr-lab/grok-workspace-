import { createFileRoute } from "@tanstack/react-router";
import { SiteShell, PageHero } from "@/components/layout/site-shell";

export const Route = createFileRoute("/about")({ component: About });

function About() {
  return (
    <SiteShell>
      <PageHero
        kicker="عن الأكاديمية"
        title="رؤية ومنهج وحوكمة"
        subtitle="تعليم هرمي، لا فتوى مفتوحة، ولا تعصب لمذهب في طبقة المبتدئ."
      />
      <div className="mx-auto max-w-3xl space-y-10 px-4 py-12 leading-8">
        <section>
          <h2 className="font-display text-2xl">الرؤية</h2>
          <p className="mt-3 text-ink-soft">
            أن يتمكن المتعلم من السير في العلوم الإسلامية سيرًا منضبطًا: من التصوّر الصحيح إلى الملكة، ثم إلى البحث، دون عشوائية الشبكة ودون اختزال العلم في شعارات.
          </p>
        </section>
        <section>
          <h2 className="font-display text-2xl">الرسالة</h2>
          <p className="mt-3 text-ink-soft">
            بناء مقررات مترابطة بمتطلبات سابقة، واختبارات إتقان، ومصادر موثّقة، وعرض علمي للخلاف. المحتوى تعليمي: لا يُفتي عن مسألتك الشخصية.
          </p>
        </section>
        <section>
          <h2 className="font-display text-2xl">المنهجية</h2>
          <ul className="mt-3 list-disc pr-5 text-ink-soft">
            <li>ثلاث طبقات داخل الدرس: مشترك، متوسط، متقدم.</li>
            <li>فصل المعلومة عن المهارة عن البحث.</li>
            <li>لا يُفتح التخصص قبل الآلة.</li>
            <li>الشهادة إتمام تعليمي لا إجازة.</li>
          </ul>
        </section>
        <section>
          <h2 className="font-display text-2xl">قالب الخلاف</h2>
          <p className="mt-3 text-ink-soft">
            تصوير المسألة، محل الاتفاق، محل الخلاف، الأقوال، الأدلة، سبب الاختلاف، الخلاصة التعليمية، والتنبيه أنها ليست فتوى.
          </p>
        </section>
        <section>
          <h2 className="font-display text-2xl">الحوكمة</h2>
          <p className="mt-3 text-ink-soft">
            حالات المحتوى: مسودة، مراجعة، اعتماد، نشر. أدوار: طالب، مدرس، مراجع علمي، مدير. لا يُنشر درس علمي دون مراجعة مناسبة في النسخة الكاملة.
          </p>
        </section>
      </div>
    </SiteShell>
  );
}
