"use client";

import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getLesson } from "@/lib/curriculum";
import { getDashboard } from "@/lib/progress";

export const Route = createFileRoute("/dashboard/progress")({ component: ProgressPage });

function ProgressPage() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getDashboard>> | null>(null);
  useEffect(() => {
    getDashboard().then(setData).catch(() => {});
  }, []);
  if (!data) return <p className="text-muted">جارٍ التحميل…</p>;
  return (
    <div>
      <h1 className="font-display text-3xl">تقدمي</h1>
      <p className="mt-2 text-sm text-muted">
        {data.overall.done} دروس من {data.overall.total}
      </p>
      <ul className="mt-6 space-y-2">
        {data.progress.map((p) => {
          const l = getLesson(p.lesson_id);
          return (
            <li key={p.lesson_id} className="flex justify-between rounded-lg border border-border px-3 py-2 text-sm">
              <Link to="/lessons/$lessonId" params={{ lessonId: p.lesson_id }}>
                {l?.title ?? p.lesson_id}
              </Link>
              <span className="text-muted">
                {p.status === "completed" ? "مكتمل" : "جارٍ"} {p.mastery_score ? `· ${p.mastery_score}٪` : ""}
              </span>
            </li>
          );
        })}
      </ul>
      {data.progress.length === 0 && <p className="mt-8 text-muted">لم تُسجَّل دروس بعد.</p>}
    </div>
  );
}
