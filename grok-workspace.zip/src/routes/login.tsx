"use client";

import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Logo } from "@/components/brand/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const [mode, setMode] = useState<"in" | "up">("in");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (mode === "up") {
        const res = await authClient.signUp.email({ email, password, name });
        if (res.error) throw new Error(res.error.message || "تعذّر إنشاء الحساب");
      } else {
        const res = await authClient.signIn.email({ email, password });
        if (res.error) throw new Error(res.error.message || "بيانات غير صحيحة");
      }
      window.location.assign("/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذّر الدخول");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="grid min-h-screen place-items-center bg-paper px-4 text-ink">
      <div className="w-full max-w-md rounded-xl border border-border bg-paper-2/50 p-8 shadow-soft">
        <Link to="/" className="mb-6 inline-block">
          <Logo />
        </Link>
        <h1 className="font-display text-2xl">{mode === "in" ? "تسجيل الدخول" : "إنشاء حساب"}</h1>
        <p className="mt-1 text-sm text-muted">احفظ تقدمك وخطتك وشهاداتك عبر حساب حقيقي.</p>

        {authEnabled ? (
          <div className="mt-6 space-y-2">
            {GROK_PROVIDERS.map((p) => (
              <button
                key={p.providerId}
                type="button"
                onClick={() => signIn(p.providerId, { callbackURL: "/dashboard" })}
                className="w-full rounded-md border border-border px-4 py-2.5 text-sm hover:bg-paper-2"
              >
                المتابعة عبر {p.label}
              </button>
            ))}
          </div>
        ) : (
          <p className="mt-4 text-sm text-muted">تسجيل الدخول غير مفعّل في هذه البيئة.</p>
        )}

        <div className="my-6 flex items-center gap-3 text-xs text-muted">
          <span className="h-px flex-1 bg-border" />
          أو بالبريد
          <span className="h-px flex-1 bg-border" />
        </div>

        <form onSubmit={onSubmit} className="space-y-3">
          {mode === "up" && (
            <label className="block text-sm">
              الاسم
              <Input className="mt-1" value={name} onChange={(e) => setName(e.target.value)} required />
            </label>
          )}
          <label className="block text-sm">
            البريد
            <Input
              className="mt-1"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              dir="ltr"
            />
          </label>
          <label className="block text-sm">
            كلمة المرور
            <Input
              className="mt-1"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={8}
              dir="ltr"
            />
          </label>
          {error && <p className="text-sm text-danger">{error}</p>}
          <Button type="submit" className="w-full" disabled={busy}>
            {busy ? "جارٍ…" : mode === "in" ? "دخول" : "إنشاء الحساب"}
          </Button>
        </form>

        <button
          type="button"
          className="mt-4 text-sm text-forest"
          onClick={() => setMode((m) => (m === "in" ? "up" : "in"))}
        >
          {mode === "in" ? "ليس لديك حساب؟ إنشاء حساب" : "لديك حساب؟ تسجيل الدخول"}
        </button>
      </div>
    </main>
  );
}
