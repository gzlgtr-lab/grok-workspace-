"use client";

import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getDashboard, markNotificationRead } from "@/lib/progress";

export const Route = createFileRoute("/dashboard/notifications")({ component: NotifPage });

function NotifPage() {
  const [data, setData] = useState<Awaited<ReturnType<typeof getDashboard>> | null>(null);
  useEffect(() => {
    getDashboard().then(setData).catch(() => {});
  }, []);
  if (!data) return <p className="text-muted">جارٍ التحميل…</p>;
  return (
    <div>
      <h1 className="font-display text-3xl">الإشعارات</h1>
      <ul className="mt-6 space-y-3">
        {data.notifications.map((n) => (
          <li key={n.id} className="rounded-xl border border-border p-4">
            <p className="font-medium">{n.title}</p>
            <p className="text-sm text-ink-soft">{n.body}</p>
            <div className="mt-2 flex gap-3 text-sm">
              {n.href && (
                <Link to={n.href as "/"} className="text-forest">
                  فتح
                </Link>
              )}
              {!n.read && (
                <button
                  type="button"
                  className="text-muted"
                  onClick={async () => {
                    await markNotificationRead({ data: { id: n.id } });
                    setData(await getDashboard());
                  }}
                >
                  تعليم كمقروء
                </button>
              )}
            </div>
          </li>
        ))}
      </ul>
      {data.notifications.length === 0 && <p className="mt-8 text-muted">لا إشعارات.</p>}
    </div>
  );
}
