"use client";

import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import {
  Bell,
  BookMarked,
  ClipboardList,
  FolderKanban,
  Gauge,
  GraduationCap,
  LayoutDashboard,
  Library,
  LineChart,
  Settings,
  StickyNote,
  Trees,
} from "lucide-react";
import { type ReactNode } from "react";
import { Logo } from "@/components/brand/logo";
import { AuthSlot, SiteHeader } from "./site-shell";
import { RequireAuth } from "./site-shell";
import { cn } from "@/lib/utils";

const ITEMS = [
  { to: "/dashboard", label: "لوحة التحكم", icon: LayoutDashboard, exact: true },
  { to: "/dashboard/plan", label: "خطتي", icon: ClipboardList },
  { to: "/dashboard/courses", label: "مقرراتي", icon: GraduationCap },
  { to: "/tree", label: "شجرة التعلم", icon: Trees },
  { to: "/dashboard/progress", label: "تقدمي", icon: Gauge },
  { to: "/dashboard/activity", label: "سجل النشاط", icon: ClipboardList },
  { to: "/dashboard/skills", label: "مهاراتي", icon: LineChart },
  { to: "/dashboard/notes", label: "ملاحظاتي", icon: StickyNote },
  { to: "/dashboard/library", label: "مكتبتي", icon: BookMarked },
  { to: "/dashboard/projects", label: "مشاريعي", icon: FolderKanban },
  { to: "/dashboard/certificates", label: "شهاداتي", icon: Library },
  { to: "/dashboard/notifications", label: "إشعارات", icon: Bell },
  { to: "/dashboard/settings", label: "الإعدادات", icon: Settings },
] as const;

export function AppShell({ children, title }: { children?: ReactNode; title?: string }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <RequireAuth>
      <div className="min-h-screen bg-paper text-ink">
        <div className="lg:hidden">
          <SiteHeader />
        </div>
        <div className="mx-auto flex max-w-7xl">
          <aside className="sticky top-0 hidden h-screen w-64 shrink-0 overflow-y-auto border-l border-border bg-paper-2/40 p-4 lg:block">
            <Link to="/" className="mb-6 block">
              <Logo />
            </Link>
            <nav className="flex flex-col gap-1">
              {ITEMS.map((it) => {
                const active = it.exact ? pathname === it.to : pathname.startsWith(it.to);
                const Icon = it.icon;
                return (
                  <Link
                    key={it.to}
                    to={it.to}
                    className={cn(
                      "flex items-center gap-2 rounded-lg px-3 py-2 text-sm",
                      active ? "bg-forest text-paper" : "text-ink-soft hover:bg-paper-2",
                    )}
                  >
                    <Icon className="size-4" />
                    {it.label}
                  </Link>
                );
              })}
            </nav>
            <div className="mt-8 border-t border-border pt-4">
              <AuthSlot />
            </div>
          </aside>
          <div className="min-w-0 flex-1 px-4 py-6 sm:px-8">
            {title && <h1 className="mb-6 font-display text-3xl">{title}</h1>}
            {children ?? <Outlet />}
          </div>
        </div>
      </div>
    </RequireAuth>
  );
}
