"use client";

import { Link, useRouterState } from "@tanstack/react-router";
import { BookOpen, Menu, Moon, Search, Sun, X } from "lucide-react";
import { useState, type ReactNode } from "react";
import { Logo } from "@/components/brand/logo";
import { Button } from "@/components/ui/button";
import { SignedIn, SignedOut, UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { useTheme } from "./theme";

const NAV = [
  { to: "/stages", label: "المراحل" },
  { to: "/tracks", label: "المسارات" },
  { to: "/tree", label: "شجرة التعلم" },
  { to: "/library", label: "المكتبة" },
  { to: "/about", label: "المنهجية" },
] as const;

export function AuthSlot() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <div className="h-9 w-24 animate-pulse rounded-md bg-paper-3" />;
  if (user) {
    return (
      <div className="flex items-center gap-3">
        <Link to="/dashboard" className="hidden text-sm text-forest sm:inline">
          لوحتي
        </Link>
        <UserButton />
      </div>
    );
  }
  return (
    <Link to="/login" className="rounded-md bg-forest px-4 py-2 text-sm text-paper">
      دخول
    </Link>
  );
}

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const { theme, toggle } = useTheme();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <header className="sticky top-0 z-40 border-b border-border/80 bg-paper/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4">
        <Link to="/" className="shrink-0">
          <Logo />
        </Link>
        <nav className="hidden items-center gap-6 md:flex">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className={
                pathname.startsWith(n.to)
                  ? "text-sm font-medium text-forest"
                  : "text-sm text-ink-soft hover:text-forest"
              }
            >
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-1">
          <Link
            to="/search"
            className="grid size-11 place-items-center rounded-md text-ink-soft hover:bg-paper-2"
            aria-label="بحث"
          >
            <Search className="size-4" />
          </Link>
          <button
            type="button"
            onClick={toggle}
            className="grid size-11 place-items-center rounded-md text-ink-soft hover:bg-paper-2"
            aria-label="الوضع الليلي"
          >
            {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
          </button>
          <div className="hidden sm:block">
            <AuthSlot />
          </div>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-md md:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-label="القائمة"
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </div>
      {open && (
        <div className="border-t border-border px-4 py-3 md:hidden">
          <div className="flex flex-col gap-2">
            {NAV.map((n) => (
              <Link key={n.to} to={n.to} className="rounded-md px-2 py-2 text-sm" onClick={() => setOpen(false)}>
                {n.label}
              </Link>
            ))}
            <Link to="/faq" className="rounded-md px-2 py-2 text-sm" onClick={() => setOpen(false)}>
              أسئلة شائعة
            </Link>
            <AuthSlot />
          </div>
        </div>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-16 border-t border-border bg-paper-2/60">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <Logo />
          <p className="mt-3 max-w-xs text-sm text-muted">
            أكاديمية رقمية للعلوم الإسلامية: منهج هرمي من التهيئة إلى البحث، وليست موسوعة ولا منبر فتوى.
          </p>
        </div>
        <div>
          <p className="text-sm font-medium">التعلم</p>
          <ul className="mt-3 space-y-2 text-sm text-ink-soft">
            <li>
              <Link to="/stages">المراحل</Link>
            </li>
            <li>
              <Link to="/tracks">المسارات</Link>
            </li>
            <li>
              <Link to="/tree">شجرة التعلم</Link>
            </li>
            <li>
              <Link to="/placement">تحديد المستوى</Link>
            </li>
          </ul>
        </div>
        <div>
          <p className="text-sm font-medium">الأكاديمية</p>
          <ul className="mt-3 space-y-2 text-sm text-ink-soft">
            <li>
              <Link to="/about">الرؤية والمنهج</Link>
            </li>
            <li>
              <Link to="/library">المكتبة</Link>
            </li>
            <li>
              <Link to="/faq">الأسئلة الشائعة</Link>
            </li>
            <li>
              <Link to="/contact">تواصل</Link>
            </li>
          </ul>
        </div>
        <div>
          <p className="text-sm font-medium">تنبيه علمي</p>
          <p className="mt-3 text-sm text-muted">
            المحتوى تعليمي مراجع. إتمام المقررات لا يؤهل للإفتاء أو الإجازة العلمية ما لم تعتمد جهة رسمية ذلك.
          </p>
          <p className="mt-4 flex items-center gap-2 text-xs text-muted">
            <BookOpen className="size-3.5" /> نسخة أولى قابلة للتوسع
          </p>
        </div>
      </div>
    </footer>
  );
}

export function SiteShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-paper text-ink">
      <SiteHeader />
      <main>{children}</main>
      <SiteFooter />
    </div>
  );
}

export function PageHero({
  kicker,
  title,
  subtitle,
  actions,
}: {
  kicker?: string;
  title: string;
  subtitle?: string;
  actions?: ReactNode;
}) {
  return (
    <section className="border-b border-border bg-forest-soft/40">
      <div className="mx-auto max-w-6xl px-4 py-10 sm:py-14">
        {kicker && <p className="text-sm text-gold">{kicker}</p>}
        <h1 className="mt-2 font-display text-3xl sm:text-4xl">{title}</h1>
        {subtitle && <p className="mt-3 max-w-2xl text-ink-soft">{subtitle}</p>}
        {actions && <div className="mt-6 flex flex-wrap gap-3">{actions}</div>}
      </div>
    </section>
  );
}

export function EmptyState({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-xl border border-dashed border-border px-6 py-12 text-center">
      <p className="font-medium">{title}</p>
      <p className="mt-2 text-sm text-muted">{body}</p>
    </div>
  );
}

export function RequireAuth({ children }: { children: ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return <div className="mx-auto max-w-6xl px-4 py-16 text-muted">جارٍ التحقق من الجلسة…</div>;
  }
  if (!user) {
    return (
      <div className="mx-auto max-w-lg px-4 py-16 text-center">
        <h1 className="font-display text-2xl">يلزم تسجيل الدخول</h1>
        <p className="mt-2 text-sm text-muted">احفظ تقدمك وشهاداتك وخطتك الشخصية بعد إنشاء حساب.</p>
        <Button asChild className="mt-6">
          <Link to="/login">تسجيل الدخول</Link>
        </Button>
      </div>
    );
  }
  return <>{children}</>;
}

export { SignedIn, SignedOut };
