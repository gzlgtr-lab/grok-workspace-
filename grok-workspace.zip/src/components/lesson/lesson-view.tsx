"use client";

import { Link } from "@tanstack/react-router";
import { Bookmark, CheckCircle2, ChevronLeft, ChevronRight, Lock } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  DOMAIN_LABEL,
  LEVEL_LABEL,
  getCourse,
  getModule,
  nextLesson,
  prevLesson,
  type Lesson,
} from "@/lib/curriculum";
import { markLessonComplete, saveNote, toggleBookmark } from "@/lib/progress";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { cn } from "@/lib/utils";

export function LessonView({
  lesson,
  bookmarked,
}: {
  lesson: Lesson;
  bookmarked?: boolean;
}) {
  const course = getCourse(lesson.courseId);
  const mod = getModule(lesson.moduleId);
  const next = nextLesson(lesson);
  const prev = prevLesson(lesson);
  const [tab, setTab] = useState<"simple" | "intermediate" | "advanced">("simple");
  const [note, setNote] = useState("");
  const [saved, setSaved] = useState(false);
  const { user } = useCurrentUserState();
  const [bm, setBm] = useState(Boolean(bookmarked));

  const body = useMemo(() => {
    if (tab === "simple") return lesson.simple;
    if (tab === "intermediate") return lesson.intermediate || lesson.simple;
    return lesson.advanced || lesson.intermediate || lesson.simple;
  }, [tab, lesson]);

  if (!lesson.available) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center">
        <Lock className="mx-auto size-8 text-gold" />
        <h1 className="mt-4 font-display text-3xl">{lesson.title}</h1>
        <p className="mt-3 text-ink-soft">{lesson.intro}</p>
        <Button asChild className="mt-6">
          <Link to="/tree">العودة إلى الشجرة</Link>
        </Button>
      </div>
    );
  }

  return (
    <article className="mx-auto max-w-3xl px-4 py-8">
      <p className="text-sm text-gold">
        {course?.title} · {mod?.title} · {LEVEL_LABEL[lesson.level]} · {lesson.durationMin} د
      </p>
      <h1 className="mt-2 font-display text-3xl sm:text-4xl">{lesson.title}</h1>
      <p className="mt-3 text-ink-soft">{lesson.intro}</p>

      <div className="mt-6 flex flex-wrap gap-2">
        {user && (
          <button
            type="button"
            className={cn(
              "inline-flex h-11 items-center gap-1 rounded-md border border-border px-3 text-sm",
              bm && "bg-gold-soft",
            )}
            onClick={async () => {
              const r = await toggleBookmark({ data: { lessonId: lesson.id } });
              setBm(r.bookmarked);
            }}
          >
            <Bookmark className="size-4" /> {bm ? "محفوظ" : "حفظ"}
          </button>
        )}
        {user && (
          <Button
            variant="outline"
            onClick={async () => {
              await markLessonComplete({ data: { lessonId: lesson.id } });
              setSaved(true);
              toast.success("عُدّ الدرس مكتملًا");
            }}
          >
            <CheckCircle2 className="size-4" /> {saved ? "مكتمل" : "تعليم كمكتمل"}
          </Button>
        )}
      </div>

      <section className="mt-8">
        <h2 className="font-display text-2xl">أهداف التعلم</h2>
        <ul className="mt-3 list-disc pr-5 text-sm text-ink-soft">
          {lesson.objectives.map((o) => (
            <li key={o}>{o}</li>
          ))}
        </ul>
      </section>

      <div className="mt-8 flex gap-2 border-b border-border">
        {(
          [
            ["simple", "شرح مبسط"],
            ["intermediate", "متوسط"],
            ["advanced", "متقدم"],
          ] as const
        ).map(([k, l]) => (
          <button
            key={k}
            type="button"
            onClick={() => setTab(k)}
            className={cn(
              "h-11 px-4 text-sm",
              tab === k ? "border-b-2 border-forest text-forest" : "text-muted",
            )}
          >
            {l}
          </button>
        ))}
      </div>
      <div className="prose-lesson mt-6 text-[1.05rem] leading-8">
        {body.split("\n\n").map((p) => (
          <p key={p.slice(0, 24)}>{p}</p>
        ))}
      </div>

      {lesson.evidences.length > 0 && (
        <section className="mt-10 space-y-4">
          <h2 className="font-display text-2xl">الأدلة والنصوص</h2>
          {lesson.evidences.map((e) => (
            <figure key={e.text} className="rounded-xl border border-gold/30 bg-gold-soft/40 px-6 py-5">
              <blockquote className="verse">{e.text}</blockquote>
              <figcaption className="mt-2 text-center text-sm text-muted">{e.source}</figcaption>
            </figure>
          ))}
        </section>
      )}

      {lesson.terms.length > 0 && (
        <section className="mt-10">
          <h2 className="font-display text-2xl">مصطلحات</h2>
          <dl className="mt-4 grid gap-3">
            {lesson.terms.map((t) => (
              <div key={t.term} className="rounded-lg border border-border p-4">
                <dt className="font-medium">{t.term}</dt>
                <dd className="mt-1 text-sm text-ink-soft">{t.definition}</dd>
              </div>
            ))}
          </dl>
        </section>
      )}

      {lesson.examples.length > 0 && (
        <section className="mt-10">
          <h2 className="font-display text-2xl">أمثلة</h2>
          <ul className="mt-3 space-y-2 text-sm text-ink-soft">
            {lesson.examples.map((x) => (
              <li key={x}>— {x}</li>
            ))}
          </ul>
        </section>
      )}

      {lesson.misconceptions.length > 0 && (
        <section className="mt-10">
          <h2 className="font-display text-2xl">أخطاء شائعة</h2>
          <ul className="mt-3 space-y-2 text-sm">
            {lesson.misconceptions.map((x) => (
              <li key={x} className="rounded-lg bg-danger/10 px-3 py-2">
                {x}
              </li>
            ))}
          </ul>
        </section>
      )}

      {lesson.thinking.length > 0 && (
        <section className="mt-10">
          <h2 className="font-display text-2xl">أسئلة تفكير</h2>
          <ul className="mt-3 list-disc pr-5 text-sm">
            {lesson.thinking.map((x) => (
              <li key={x}>{x}</li>
            ))}
          </ul>
        </section>
      )}

      <section className="mt-10 rounded-xl border border-border p-5">
        <h2 className="font-display text-xl">نشاط</h2>
        <p className="mt-2 text-sm text-ink-soft">{lesson.activity}</p>
        <h3 className="mt-4 text-sm font-medium">تمرين</h3>
        <p className="mt-1 text-sm text-ink-soft">{lesson.exercise}</p>
      </section>

      {lesson.flashcards.length > 0 && (
        <section className="mt-10">
          <h2 className="font-display text-2xl">بطاقات مراجعة</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {lesson.flashcards.map((c) => (
              <Flash key={c.id} front={c.front} back={c.back} />
            ))}
          </div>
        </section>
      )}

      <section className="mt-10 rounded-xl bg-forest-soft/50 p-5">
        <h2 className="font-display text-xl">خلاصة</h2>
        <p className="mt-2 text-sm leading-7">{lesson.summary}</p>
      </section>

      {user && (
        <section className="mt-10">
          <h2 className="font-display text-xl">مذكرة</h2>
          <Textarea
            className="mt-2"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="اكتب فائدة أو إشكالًا…"
          />
          <Button
            className="mt-3"
            variant="outline"
            disabled={!note.trim()}
            onClick={async () => {
              await saveNote({ data: { lessonId: lesson.id, body: note.trim() } });
              setNote("");
              toast.success("حُفظت الملاحظة");
            }}
          >
            حفظ الملاحظة
          </Button>
        </section>
      )}

      <div className="mt-10 flex flex-col gap-3 sm:flex-row sm:justify-between">
        {prev ? (
          <Button asChild variant="outline">
            <Link to="/lessons/$lessonId" params={{ lessonId: prev.id }}>
              <ChevronRight className="size-4" /> {prev.title}
            </Link>
          </Button>
        ) : (
          <span />
        )}
        <Button asChild>
          <Link to="/quizzes/$quizId" params={{ quizId: lesson.quizId }}>
            اختبار الدرس
          </Link>
        </Button>
        {next ? (
          <Button asChild variant="outline">
            <Link to="/lessons/$lessonId" params={{ lessonId: next.id }}>
              {next.title} <ChevronLeft className="size-4" />
            </Link>
          </Button>
        ) : (
          <span />
        )}
      </div>

      <p className="mt-10 text-xs text-muted">
        مجال: {course ? DOMAIN_LABEL[course.domain] : ""} · المادة تعليمية وليست فتوى.
      </p>
    </article>
  );
}

function Flash({ front, back }: { front: string; back: string }) {
  const [on, setOn] = useState(false);
  return (
    <button
      type="button"
      onClick={() => setOn((v) => !v)}
      className="min-h-28 rounded-xl border border-border bg-paper-2 p-4 text-start"
    >
      <p className="text-xs text-muted">{on ? "الظهر" : "الوجه"}</p>
      <p className="mt-2 text-sm">{on ? back : front}</p>
    </button>
  );
}
