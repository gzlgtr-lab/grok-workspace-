import { cn } from "@/lib/utils";
import type { HTMLAttributes } from "react";

export function Badge({ className, ...props }: HTMLAttributes<HTMLSpanElement>) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border border-border bg-paper-2 px-2.5 py-0.5 text-xs text-ink-soft",
        className,
      )}
      {...props}
    />
  );
}
