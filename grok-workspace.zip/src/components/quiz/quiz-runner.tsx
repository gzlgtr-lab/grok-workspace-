"use client";

import { Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { getQuiz, questionsOf, type Question } from "@/lib/curriculum";
import { submitQuiz } from "@/lib/progress";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { cn } from "@/lib/utils";

export function QuizRunner({ quizId }: { quizId: string }) {
  const quiz = getQuiz(quizId);
  const questions = useMemo(() => questionsOf(quizId), [quizId]);
  const { user, isPending } = useCurrentUserState();
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [result, setResult] = useState<Awaited<ReturnType<typeof submitQuiz>> | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!quiz || questions.length === 0) {
    return (
      <div className="px-4 py-16 text-center">
        <p>لا أسئلة في هذا الاختبار بعد.</p>
        <Link to="/tree" className="mt-4 inline-block text-forest">
          الشجرة
        </Link>
      </div>
    );
  }

  const q = questions[index];

  async function finish() {
    if (!user) {
      setError("سجّل الدخول لحفظ النتيجة.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const r = await submitQuiz({ data: { quizId, answers } });
      setResult(r);
    } catch (e) {
      setError(e instanceof Error ? e.message : "تعذّر التصحيح");
    } finally {
      setBusy(false);
    }
  }

  if (result) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-10">
        <p className="text-sm text-gold">{quiz.title}</p>
        <h1 className="mt-2 font-display text-3xl">النتيجة: {result.percent}٪</h1>
        <p className="mt-2 text-ink-soft">
          {result.score} من {result.total}
          {quiz.kind !== "placement" && (result.passed ? " · ناجح" : ` · الإتقان من ${result.passPercent}٪`)}
        </p>
        <div className="mt-8 space-y-4">
          {questions.map((qn) => {
            const rev = result.review.find((r) => r.id === qn.id);
            return (
              <div key={qn.id} className="rounded-xl border border-border p-4">
                <p className="font-medium">{qn.prompt}</p>
                <p className={cn("mt-2 text-sm", rev?.ok ? "text-success" : "text-danger")}>
                  {rev?.ok ? "إجابة صحيحة" : "إجابة غير صحيحة"} · {qn.explanation}
                </p>
              </div>
            );
          })}
        </div>
        {quiz.kind === "placement" && (
          <div className="mt-8 rounded-xl bg-forest-soft p-5">
            <h2 className="font-display text-xl">توزيع المهارات</h2>
            <ul className="mt-3 space-y-1 text-sm">
              {Object.entries(result.skills).map(([k, v]) => (
                <li key={k}>
                  {k}: {v.score}/{v.total}
                </li>
              ))}
            </ul>
            <Button asChild className="mt-4">
              <Link to="/dashboard/plan">بناء خطة شخصية</Link>
            </Button>
          </div>
        )}
        <div className="mt-6 flex gap-3">
          <Button asChild variant="outline">
            <Link to="/dashboard">لوحتي</Link>
          </Button>
          {quiz.kind === "lesson" && (
            <Button asChild>
              <Link to="/lessons/$lessonId" params={{ lessonId: quizId.replace(/-q$/, "") }}>
                العودة للدرس
              </Link>
            </Button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-10">
      <p className="text-sm text-gold">{quiz.title}</p>
      <div className="mt-2 h-2 overflow-hidden rounded-full bg-paper-3">
        <div
          className="h-full bg-forest transition-[width] duration-200"
          style={{ width: `${((index + 1) / questions.length) * 100}%` }}
        />
      </div>
      <p className="mt-2 text-xs text-muted tabular-nums">
        {index + 1} / {questions.length}
      </p>
      <QuestionCard
        question={q}
        value={answers[q.id]}
        onChange={(i) => setAnswers((a) => ({ ...a, [q.id]: i }))}
      />
      {error && <p className="mt-3 text-sm text-danger">{error}</p>}
      <div className="mt-6 flex justify-between">
        <Button variant="outline" disabled={index === 0} onClick={() => setIndex((i) => i - 1)}>
          السابق
        </Button>
        {index < questions.length - 1 ? (
          <Button disabled={answers[q.id] === undefined} onClick={() => setIndex((i) => i + 1)}>
            التالي
          </Button>
        ) : (
          <Button disabled={busy || isPending || Object.keys(answers).length < questions.length} onClick={finish}>
            {busy ? "تصحيح…" : "إنهاء وتصحيح"}
          </Button>
        )}
      </div>
    </div>
  );
}

function QuestionCard({
  question,
  value,
  onChange,
}: {
  question: Question;
  value?: number;
  onChange: (i: number) => void;
}) {
  return (
    <div className="mt-8">
      <h1 className="font-display text-2xl">{question.prompt}</h1>
      <div className="mt-5 grid gap-2">
        {question.options.map((opt, i) => (
          <button
            key={opt}
            type="button"
            onClick={() => onChange(i)}
            className={cn(
              "rounded-xl border px-4 py-3 text-start text-sm",
              value === i ? "border-forest bg-forest-soft" : "border-border hover:bg-paper-2",
            )}
          >
            {opt}
          </button>
        ))}
      </div>
    </div>
  );
}
