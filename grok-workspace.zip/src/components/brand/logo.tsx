import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 48 48"
      className={cn("size-9", className)}
      aria-hidden="true"
      fill="none"
    >
      <rect width="48" height="48" rx="12" className="fill-forest" />
      <path
        d="M24 8L28.8 19.2 41 24 28.8 28.8 24 40 19.2 28.8 7 24 19.2 19.2 24 8Z"
        className="stroke-gold"
        strokeWidth="1.4"
        fill="color-mix(in oklab, var(--gold-soft) 55%, transparent)"
      />
      <path
        d="M16 27.5V22.5C16 20.5 19.6 19 24 19C28.4 19 32 20.5 32 22.5V27.5C32 29.5 28.4 31 24 31C19.6 31 16 29.5 16 27.5Z"
        className="stroke-paper"
        strokeWidth="1.4"
      />
      <path d="M24 19V31" className="stroke-paper" strokeWidth="1.2" />
    </svg>
  );
}

export function Logo({ compact }: { compact?: boolean }) {
  return (
    <span className="flex items-center gap-2.5">
      <LogoMark />
      {!compact && (
        <span className="leading-tight">
          <span className="block font-display text-lg text-forest">أكاديمية العلم</span>
          <span className="block text-[11px] text-muted">علوم إسلامية · من الصفر إلى الباحث</span>
        </span>
      )}
    </span>
  );
}
