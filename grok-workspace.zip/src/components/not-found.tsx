import { Link } from "@tanstack/react-router";

export function NotFound() {
  return (
    <main className="flex min-h-[70vh] flex-col items-center justify-center gap-4 bg-paper px-6 text-center text-ink">
      <p className="text-sm tracking-widest text-gold">٤٠٤</p>
      <h1 className="font-display text-3xl">هذه الصفحة ليست في المنهج</h1>
      <p className="max-w-md text-muted">ربما نُقل الدرس أو تغيّر رابطه. عد إلى الشجرة أو لوحة التحكم.</p>
      <div className="flex gap-3">
        <Link to="/" className="rounded-md bg-forest px-5 py-2.5 text-sm text-paper">
          الرئيسية
        </Link>
        <Link to="/tree" className="rounded-md border border-border px-5 py-2.5 text-sm">
          شجرة التعلم
        </Link>
      </div>
    </main>
  );
}
