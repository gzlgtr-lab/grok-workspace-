create table if not exists student_profiles (
  user_id text primary key,
  display_name text,
  goal text,
  weekly_minutes integer not null default 30,
  current_track text,
  current_stage text default '0',
  placement_completed boolean not null default false,
  placement_scores jsonb,
  font_size text not null default 'md',
  theme text not null default 'light',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists user_roles (
  user_id text primary key,
  role text not null default 'student',
  created_at timestamptz not null default now()
);

create table if not exists lesson_progress (
  id serial primary key,
  user_id text not null,
  lesson_id text not null,
  status text not null default 'in_progress',
  mastery_score integer,
  last_section text,
  completed_at timestamptz,
  updated_at timestamptz not null default now(),
  unique (user_id, lesson_id)
);
create index if not exists lesson_progress_user_idx on lesson_progress (user_id);

create table if not exists quiz_attempts (
  id serial primary key,
  user_id text not null,
  quiz_id text not null,
  answers jsonb not null,
  score integer not null,
  total integer not null,
  percent integer not null,
  passed boolean not null,
  created_at timestamptz not null default now()
);
create index if not exists quiz_attempts_user_idx on quiz_attempts (user_id);

create table if not exists student_notes (
  id serial primary key,
  user_id text not null,
  lesson_id text not null,
  body text not null,
  created_at timestamptz not null default now()
);
create index if not exists student_notes_user_idx on student_notes (user_id);

create table if not exists bookmarks (
  user_id text not null,
  lesson_id text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, lesson_id)
);

create table if not exists certificates (
  id serial primary key,
  user_id text not null,
  kind text not null,
  target_id text not null,
  title text not null,
  hours integer,
  score integer,
  verify_code text not null unique,
  issued_at timestamptz not null default now()
);
create index if not exists certificates_user_idx on certificates (user_id);
create index if not exists certificates_code_idx on certificates (verify_code);

create table if not exists projects (
  id serial primary key,
  user_id text not null,
  title text not null,
  description text,
  status text not null default 'draft',
  course_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists projects_user_idx on projects (user_id);

create table if not exists notifications (
  id serial primary key,
  user_id text not null,
  title text not null,
  body text,
  href text,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_idx on notifications (user_id);

create table if not exists study_plans (
  user_id text primary key,
  kind text not null,
  minutes_per_day integer not null default 30,
  lesson_ids jsonb not null default '[]'::jsonb,
  generated_at timestamptz not null default now()
);

create table if not exists flashcard_reviews (
  user_id text not null,
  card_id text not null,
  due_at timestamptz not null default now(),
  interval_days integer not null default 1,
  ease integer not null default 0,
  primary key (user_id, card_id)
);

create table if not exists content_reviews (
  id serial primary key,
  target_type text not null,
  target_id text not null,
  status text not null default 'draft',
  reviewer_id text,
  notes text,
  version integer not null default 1,
  updated_at timestamptz not null default now()
);
